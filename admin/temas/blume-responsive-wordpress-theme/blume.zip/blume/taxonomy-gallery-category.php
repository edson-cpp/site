<?php get_header(); global $query_string; query_posts($query_string.'&post_type=gallery&posts_per_page=-1'); ?>
    <!-- Our Works -->
    <section class="our-works portfolio">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Our Works','aletheme'); ?></span><span>]</span>
            </div>

            <?php global $post;
            $terms = get_the_terms($post->id, 'gallery-category');
                foreach($terms as $term){
                    if($term->slug){
                        $cur_page_slug = $term->slug;
                    }
                }
            ?>

            <div class="menu">
                <a href="<?php echo home_url(); ?>/gallery"><?php _e('All', 'aletheme')?></a>
                <?php $args = array(
                    'type'                     => 'gallery',
                    'child_of'                 => 0,
                    'parent'                   => '',
                    'orderby'                  => 'name',
                    'order'                    => 'ASC',
                    'hide_empty'               => 1,
                    'hierarchical'             => 1,
                    'exclude'                  => '',
                    'include'                  => '',
                    'number'                   => '',
                    'taxonomy'                 => 'gallery-category',
                    'pad_counts'               => false );

                $categories = get_categories( $args );

                foreach($categories as $cat){
                    if($cur_page_slug){
                        if($cat->slug == $cur_page_slug) { $active_status = "active";} else {$active_status="";}
                    }

                    echo '<a href="'.home_url().'/gallery-category/'.$cat->slug.'" class="'.$active_status.'">'.$cat->name.'</a>';
                }
                ?>
            </div>

            <div class="gallery cf">

                <?php $g_counter=0; if (have_posts()) : while (have_posts()) : the_post(); $g_counter++; ?>
                    <div class="post <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") { echo "col-6"; } else {echo "col-3";} ?>">
                        <a href="<?php the_permalink(); ?>">
                            <div class="outlines">
                                <div class="triangle"><p>+</p></div>
                            </div>
                            <div class="mask"></div>
                            <span><?php echo the_title(); ?></span>

                            <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") {
                                echo get_the_post_thumbnail($post->ID,'gallery-big');
                            } else {
                                echo get_the_post_thumbnail($post->ID,'gallery-mini');
                            } ?>
                        </a>
                    </div>
                <?php endwhile; else: ?>
                    <?php ale_part('notfound')?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php get_footer(); ?>