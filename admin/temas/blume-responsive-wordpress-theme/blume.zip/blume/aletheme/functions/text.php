<?php
/**
 * Truncates string with specified length.
 * 
 * @param string $string
 * @param int $length
 * @param string $etc
 * @param bool $break_words
 * @param bool $middle
 * @return string
 */
function ale_truncate($string, $length = 80, $etc = '&#133;', $break_words = false, $middle = false) {
    if ($length == 0)
        return '';

    if (strlen($string) > $length) {
        $length -= min($length, strlen($etc));
        if (!$break_words && !$middle) {
            $string = preg_replace('/\s+?(\S+)?$/', '', substr($string, 0, $length+1));
        }
        if(!$middle) {
            return substr($string, 0, $length) . $etc;
        } else {
            return substr($string, 0, $length/2) . $etc . substr($string, -$length/2);
        }
    } else {
        return $string;
    }
}

/**
 * Check if the url has http:// at the beginning
 * @param string $url
 * @return string 
 */
function ale_get_url($url) {
    if (preg_match('~^https?\:\/\/~si', $url)) {
        return $url;
    } else {
        return 'http://' . $url;
    }
}

function ale_url($url) {
    echo ale_get_url($url);
}

//Short Excerpt
function ale_trim_excerpt($length) {
    global $post;
    $explicit_excerpt = $post->post_excerpt;
    if ( '' == $explicit_excerpt ) {
        $text = get_the_content('');
        $text = apply_filters('the_content', $text);
        $text = str_replace(']]>', ']]>', $text);
    }
    else {
        $text = apply_filters('the_content', $explicit_excerpt);
    }
    $text = strip_shortcodes( $text ); // optional
    $text = strip_tags($text);
    $excerpt_length = $length;
    $words = explode(' ', $text, $excerpt_length + 1);
    if (count($words)> $excerpt_length) {
        array_pop($words);
        array_push($words, '[&hellip;]');
        $text = implode(' ', $words);
        $text = apply_filters('the_excerpt',$text);
    }
    return $text;
}