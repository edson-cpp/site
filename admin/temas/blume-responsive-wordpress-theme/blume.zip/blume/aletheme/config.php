<?php
/**
 * Get current theme options
 * 
 * @return array
 */
function aletheme_get_options() {
	$comments_style = array(
		'wp'  => 'Alethemes Comments',
		'fb'  => 'Facebook Comments',
		'dq'  => 'DISQUS',
		'lf'  => 'Livefyre',
		'off' => 'Disable All Comments',
	);

    $colorscheme = array(
        'color1'  => 'Scheme 1',
        'color2'  => 'Scheme 2',
        'color3'  => 'Scheme 3',
        'color4'  => 'Scheme 4',
        'color5'  => 'Scheme 5',
        'color6'  => 'Scheme 6',
    );

    $headerfont = array_merge(ale_get_safe_webfonts(), ale_get_google_webfonts());

    $background_defaults = array(
        'color' => '#ffffff',
        'image' => '',
        'repeat' => 'repeat',
        'position' => 'top center',
        'attachment'=>'scroll'
    );

	
	$imagepath =  ALETHEME_URL . '/assets/images/';
	
	$options = array();
		
	$options[] = array("name" => "Theme",
						"type" => "heading");

    $options[] = array( "name" => "Site Logo",
                        "desc" => "Upload or put the site logo link (Default logo size: 147-147px)",
                        "id" => "ale_sitelogo",
                        "std" => "",
                        "type" => "upload");

    $options[] = array( "name" => "Mobile Site Logo",
                        "desc" => "Upload or put the site logo link (Default logo size: 100-100px)",
                        "id" => "ale_mobsitelogo",
                        "std" => "",
                        "type" => "upload");

    $options[] = array( "name" => "Custom Pattern",
                        "desc" => "Upload or put the pattern link (You can use patterns from - http://subtlepatterns.com/)",
                        "id" => "ale_sitepattern",
                        "std" => "",
                        "type" => "upload");

    $options[] = array( 'name' => "Manage Background",
                        'desc' => "Select the background color, or upload a custom background image. Default background is the #ffffff color",
                        'id' => 'ale_background',
                        'std' => $background_defaults,
                        'type' => 'background');

    $options[] = array( "name" => "Select an existing Color Scheme",
                        "desc" => "Select an existing Color Scheme or add your custom colors 1 and 2 below.",
                        "id" => "ale_colscheme",
                        "std" => "color1",
                        "type" => "select",
                        "options" => $colorscheme);

    $options[] = array( "name" => "Select the Firss Site Color",
                        "desc" => "Select the first site color",
                        "id" => "ale_firstcolor",
                        "std" => "",
                        "type" => "color");

    $options[] = array( "name" => "Select the Second Site Color",
                        "desc" => "Select the second site color",
                        "id" => "ale_secondcolor",
                        "std" => "",
                        "type" => "color");

    $options[] = array( "name" => "Uplaod a favicon icon",
                        "desc" => "Upload or put the link of your favicon icon",
                        "id" => "ale_favicon",
                        "std" => "",
                        "type" => "upload");

	$options[] = array( "name" => "Comments Style",
						"desc" => "Choose your comments style. If you want to use DISQUS comments please install and activate this plugin from <a href=\"" . admin_url('plugin-install.php?tab=search&type=term&s=Disqus+Comment+System&plugin-search-input=Search+Plugins') . "\">Wordpress Repository</a>.  If you want to use Livefyre Realtime Comments comments please install and activate this plugin from <a href=\"" . admin_url('plugin-install.php?tab=search&type=term&s=Livefyre+Realtime+Comments&plugin-search-input=Search+Plugins') . "\">Wordpress Repository</a>.",
						"id" => "ale_comments_style",
						"std" => "wp",
						"type" => "select",
						"options" => $comments_style);

	$options[] = array( "name" => "AJAX Comments",
						"desc" => "Use AJAX on comments posting (works only with Alethemes Comments selected).",
						"id" => "ale_ajax_comments",
						"std" => "1",
						"type" => "checkbox");

	$options[] = array( "name" => "Social Sharing",
						"desc" => "Enable social sharing for posts.",
						"id" => "ale_social_sharing",
						"std" => "1",
						"type" => "checkbox");

    $options[] = array( "name" => "Copyrights",
                        "desc" => "Your copyright message.",
                        "id" => "ale_copyrights",
                        "std" => "",
                        "type" => "editor");

    $options[] = array( "name" => "Home Page Slider slug",
                        "desc" => "Insert the slider slug. Get the slug on Sliders Section",
                        "id" => "ale_homeslugfull",
                        "std" => "",
                        "type" => "text");



    $options[] = array( "name" => "Typography",
                        "type" => "heading");

    $options[] = array( "name" => "Select the body Font from Google Library",
                        "desc" => "The default Font is - Raleway",
                        "id" => "ale_headerfont",
                        "std" => "Raleway",
                        "type" => "select",
                        "options" => $headerfont);

    $options[] = array( "name" => "Select the body Font (Extended) from Google Library",
                        "desc" => "The default Font (extended) is - 400",
                        "id" => "ale_headerfontex",
                        "std" => "400",
                        "type" => "text",
                        );

    $options[] = array( "name" => "Select the Headers Font from Google Library",
                        "desc" => "The default Font is - Lora",
                        "id" => "ale_mainfont",
                        "std" => "Lora",
                        "type" => "select",
                        "options" => $headerfont);

    $options[] = array( "name" => "Select the Headers Font (Extended) from Google Library",
                        "desc" => "The default Font (extended) is - 400,400italic",
                        "id" => "ale_mainfontex",
                        "std" => "400,700",
                        "type" => "text",
                        );

    $options[] = array( 'name' => "H1 Style",
                        'desc' => "Change the h1 style",
                        'id' => 'ale_h1sty',
                        'std' => array('size' => '24px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "H2 Style",
                        'desc' => "Change the h2 style",
                        'id' => 'ale_h2sty',
                        'std' => array('size' => '22px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "H3 Style",
                        'desc' => "Change the h3 style",
                        'id' => 'ale_h3sty',
                        'std' => array('size' => '20px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "H4 Style",
                        'desc' => "Change the h4 style",
                        'id' => 'ale_h4sty',
                        'std' => array('size' => '18px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "H5 Style",
                        'desc' => "Change the h5 style",
                        'id' => 'ale_h5sty',
                        'std' => array('size' => '16px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "H6 Style",
                        'desc' => "Change the h6 style",
                        'id' => 'ale_h6sty',
                        'std' => array('size' => '14px','face' => 'Lora','style' => 'normal','color' => '#4d4d4d'),
                        'type' => 'typography');

    $options[] = array( 'name' => "Body Style",
                        'desc' => "Change the body font style",
                        'id' => 'ale_bodystyle',
                        'std' => array('size' => '16px','face' => 'Raleway','style' => 'normal','color' => '#333333'),
                        'type' => 'typography');

	$options[] = array( "name" => "Social",
						"type" => "heading");

    $options[] = array( "name" => "Twitter",
                        "desc" => "Your twitter profile URL.",
                        "id" => "ale_twi",
                        "std" => "",
                        "type" => "text");

	$options[] = array( "name" => "Facebook",
						"desc" => "Your facebook profile URL.",
						"id" => "ale_fb",
						"std" => "",
						"type" => "text");

    $options[] = array( "name" => "Pinterest",
                        "desc" => "Your pinteres profile URL.",
                        "id" => "ale_pint",
                        "std" => "",
                        "type" => "text");

    $options[] = array( "name" => "Flickr",
                        "desc" => "Your flickr profile URL.",
                        "id" => "ale_flickr",
                        "std" => "",
                        "type" => "text");

    $options[] = array( "name" => "Instagram",
                        "desc" => "Your instagram profile URL.",
                        "id" => "ale_insta",
                        "std" => "",
                        "type" => "text");

	
	$options[] = array( "name" => "Facebook Application ID",
						"desc" => "If you have Application ID you can connect the blog to your Facebook Profile and monitor statistics there.",
						"id" => "ale_fb_id",
						"std" => "",
						"type" => "text");
	
	$options[] = array( "name" => "Enable Open Graph",
						"desc" => "The <a href=\"http://www.ogp.me/\">Open Graph</a> protocol enables any web page to become a rich object in a social graph.",
						"id" => "ale_og_enabled",
						"std" => "",
						"type" => "checkbox");


	
	$options[] = array( "name" => "Advanced Settings",
						"type" => "heading");
	
	$options[] = array( "name" => "Google Analytics",
						"desc" => "Please insert your Google Analytics code here. Example: <strong>UA-22231623-1</strong>",
						"id" => "ale_ga",
						"std" => "",
						"type" => "text");
	
	$options[] = array( "name" => "Footer Code",
						"desc" => "If you have anything else to add in the footer - please add it here.",
						"id" => "ale_footer_info",
						"std" => "",
						"type" => "textarea");

    $options[] = array( "name" => "Custom CSS Styles",
                        "desc" => "You can add here your styles. ex. .boxclass { padding:10px; }",
                        "id" => "ale_customcsscode",
                        "std" => "",
                        "type" => "textarea");

    $options[] = array( "name" => "Enable or Disable the Skin Selector Box",
                        "desc" => "Check if you want to show the Skin Selector Box",
                        "id" => "ale_skinselector",
                        "std" => "0",
                        "type" => "checkbox");

    $options[] = array( "name" => "Sidebars",
                        "type" => "heading");

    $options[] = array( 'name' => "Sidebar type on Blog pages",
                        'desc' => "Select sidebar type",
                        'id' => 'ale_sidebarblog',
                        'std' => '1col-fixed',
                        'type' => 'images',
                        'options' => array(
                            '1col-fixed' => $imagepath . '1col.png',
                            '2c-l-fixed' => $imagepath . '2cl.png',
                            '2c-r-fixed' => $imagepath . '2cr.png')
                        );

    $options[] = array( "name" => "Other",
                        "type" => "heading");

    $options[] = array( "name" => "Footer navigation title",
                        "desc" => "Paste here your footer navigation title",
                        "id" => "ale_footnavtitle",
                        "std" => "NAVIGATION",
                        "type" => "text");

    $options[] = array( "name" => "Footer contact bloc title",
                        "desc" => "Paste here your footer contact bloc title",
                        "id" => "ale_footcontitle",
                        "std" => "OUR CONTACTS",
                        "type" => "text");

    $options[] = array( "name" => "Footer contact first col title",
                        "desc" => "Paste here your footer contact first col title",
                        "id" => "ale_footcolonetitle",
                        "std" => "OFFICE IN TORRONTO",
                        "type" => "text");

    $options[] = array( "name" => "Footer contact second col title",
                        "desc" => "Paste here your footer contact second col title",
                        "id" => "ale_footcoltwotitle",
                        "std" => "OFFICE IN CHISINAU",
                        "type" => "text");

    $options[] = array( "name" => "Phone 1",
                        "desc" => "Paste here your phone 1",
                        "id" => "ale_phone1",
                        "std" => "+ 8 800 435-17-20",
                        "type" => "text");

    $options[] = array( "name" => "Phone 2",
                        "desc" => "Paste here your phone 2",
                        "id" => "ale_phone2",
                        "std" => "+ 8 800 487-17-43",
                        "type" => "text");

    $options[] = array( "name" => "Phone 3",
                        "desc" => "Paste here your phone 3",
                        "id" => "ale_phone3",
                        "std" => "+ 8 800 435-17-20",
                        "type" => "text");

    $options[] = array( "name" => "Phone 4",
                        "desc" => "Paste here your phone 4",
                        "id" => "ale_phone4",
                        "std" => "+ 8 800 487-17-43",
                        "type" => "text");

    $options[] = array( "name" => "Email 1",
                        "desc" => "Paste here your email 1",
                        "id" => "ale_email1",
                        "std" => "info@blume.co.uk",
                        "type" => "text");

    $options[] = array( "name" => "Email 2",
                        "desc" => "Paste here your email 2",
                        "id" => "ale_email2",
                        "std" => "info@blume.co.uk",
                        "type" => "text");

    $options[] = array( "name" => "Address 1",
                        "desc" => "Paste here your address 1",
                        "id" => "ale_address1",
                        "std" => "Germany Berlin, Main str. 43",
                        "type" => "text");

    $options[] = array( "name" => "Address 2",
                        "desc" => "Paste here your address 2",
                        "id" => "ale_address2",
                        "std" => "Moldova Chisinau, Stefan 1",
                        "type" => "text");
	
	return $options;
}

/**
 * Add custom scripts to Options Page
 */
function aletheme_options_custom_scripts() {
 ?>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery('#ale_commentongallery').click(function() {
        jQuery('#section-ale_gallerycomments_style').fadeToggle(400);
    });
    if (jQuery('#ale_commentongallery:checked').val() !== undefined) {
        jQuery('#section-ale_gallerycomments_style').show();
    }
});
</script>

<?php
}

/**
 * Add Metaboxes
 * @param array $meta_boxes
 * @return array 
 */
function aletheme_metaboxes($meta_boxes) {
	
	$meta_boxes = array();

    $prefix = "ale_";


    $meta_boxes[] = array(
        'id'         => 'pagebg_metabox',
        'title'      => 'Custom Background',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Custom Background',
                'desc' => 'Upload your custom background or leave this field blank to show the main site background from Theme Options',
                'id'   => $prefix . 'custombg',
                'type'    => 'file',
            ),
            array(
                'name' => 'Custom CSS',
                'desc' => 'Add custom CSS to this page',
                'id'   => $prefix . 'custompagecss',
                'std' => '',
                'type'    => 'textarea_code',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_page_metabox',
        'title'      => 'Post Data',
        'pages'      => array( 'post', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Video Link',
                'desc' => 'You can put here the links from youtube.com, vimeo.com, blip.tv, dailymotion.com, flickr.com, smugmug.com, hulu.com, viddler.com, qik.com, revision3.com, photobucket.com, scribd.com, wordpress.tv, polldaddy.com, funnyordie.com, twitter.com, soundcloud.com, slideshare.net, instagram.com',
                'id'   => $prefix . 'videopostlink',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'testimonials_metabox',
        'title'      => 'Testimonials Options',
        'pages'      => array( 'testimonials', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Instagram Profile link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'tesinst',
                'type'    => 'text',
            ),
            array(
                'name' => 'Flickr Profile link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'tesflickr',
                'type'    => 'text',
            ),
            array(
                'name' => 'Pinterest Profile link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'tespint',
                'type'    => 'text',
            ),
            array(
                'name' => 'Twitter Profile link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'testwi',
                'type'    => 'text',
            ),
            array(
                'name' => 'Facebook Profile link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'tesfb',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'about_metabox',
        'title'      => 'About page Option',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'show_on'    => array( 'key' => 'page-template', 'value' => array('template-about.php'), ), // Specific post templates to display this metabox
        'fields' => array(

            array(
                'name' => 'About Box Settings',
                'desc' => 'Set up your about box on Home page',
                'id'   => $prefix . 'abautsettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the about box sub title',
                'desc' => 'Insert the sub title',
                'id'   => $prefix . 'aboutsubtitle',
                'std'  => 'WHO WE ARE',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about box description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc',
                'std'  => 'About description here',
                'type'    => 'wysiwyg',
                'options' => array(    'textarea_rows' => 5, ),
            ),

            array(
                'name' => 'Insert the about member 1 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic1',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 2 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic2',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 3 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic3',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 4 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the about member 1 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 2 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 3 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 4 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about member 1 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 2 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 3 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 4 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about member 1 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc1',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 2 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc2',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 3 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc3',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 4 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc4',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Skills Box Settings',
                'desc' => 'Set up your skills box on Home page',
                'id'   => $prefix . 'skillssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the skills box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle',
                'std'  => 'OUR SKILLS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle1',
                'std'  => 'PROGRAMMING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper1',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle2',
                'std'  => 'WEB DEVELOPING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper2',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle3',
                'std'  => 'WEB DESIGN',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper3',
                'std'  => '90',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle4',
                'std'  => 'WORDPRESS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper4',
                'std'  => '100',
                'type'    => 'text',
            ),

            array(
                'name' => 'Facts Box Settings',
                'desc' => 'Set up your facts box on Home page',
                'id'   => $prefix . 'factssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the facts box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle',
                'std'  => 'HOW ABOUT SOME FUN FACTS ABOUT OUR AGENCY?',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the facts box bg image',
                'desc' => 'Insert the image',
                'id'   => $prefix . 'factsimage',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the fact 1 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle1',
                'std'  => 'Pizzas Ordered',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 2 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle2',
                'std'  => 'Clients Worked With',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 3 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle3',
                'std'  => 'Projects Completed',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 4 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle4',
                'std'  => 'Magazines Published',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 1 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount1',
                'std'  => '520',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 2 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount2',
                'std'  => '90',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 3 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount3',
                'std'  => '129',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 4 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount4',
                'std'  => '20',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'contact_page_metabox',
        'title'      => 'Contact Page Options',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'show_on'    => array( 'key' => 'page-template', 'value' => array('template-contact.php'), ), // Specific post templates to display this metabox
        'fields' => array(
            array(
                'name' => 'Map HTML code (iframe)',
                'desc' => 'Insert the htmlcode',
                'id'   => $prefix . 'htmlmap',
                'std'  => '<iframe src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Stefan+cel+Mare+si+Sfant+Boulevard,+Chisinau,+Moldova&amp;aq=0&amp;oq=chisinau,+stefac&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;t=m&amp;ie=UTF8&amp;hq=&amp;hnear=Stefan+cel+Mare+si+Sfant+Blvd,+Kishinev,+Moldova&amp;z=14&amp;ll=47.025595,28.830955&amp;output=embed"></iframe>',
                'type' => 'textarea_code',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'service_metabox',
        'title'      => 'Services Options',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'show_on'    => array( 'key' => 'page-template', 'value' => array('template-service.php'), ), // Specific post templates to display this metabox
        'fields' => array(
            array(
                'name' => 'Services Box Settings',
                'desc' => 'Set up your services box on Home page',
                'id'   => $prefix . 'sersettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the service 1 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic1',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 1 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov1',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 1 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit1',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 1 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'servdesc1',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Insert the service 2 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic2',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 2 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov2',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 2 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit2',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 2 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'servdesc2',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Insert the service 3 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic3',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 3 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov3',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 3 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit3',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 3 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'servdesc3',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Insert the service 4 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 4 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 4 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 4 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'servdesc4',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Toggle Box Settings',
                'desc' => 'Set up your toggle box on Home page',
                'id'   => $prefix . 'togsettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the Toggle box Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'toggletit',
                'std'  => 'WHY CHOOSE US',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the Toggle item title #1',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'toggletit1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the Toggle item description #1',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'toggledesc1',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the Toggle item title #2',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'toggletit2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the Toggle item description #2',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'toggledesc2',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the Toggle item title #3',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'toggletit3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the Toggle item description #3',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'toggledesc3',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the Toggle item title #4',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'toggletit4',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the Toggle item description #4',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'toggledesc4',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Skills Box Settings',
                'desc' => 'Set up your skills box on Home page',
                'id'   => $prefix . 'skillssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the skills box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle',
                'std'  => 'OUR SKILLS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle1',
                'std'  => 'PROGRAMMING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper1',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle2',
                'std'  => 'WEB DEVELOPING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper2',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle3',
                'std'  => 'WEB DESIGN',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper3',
                'std'  => '90',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle4',
                'std'  => 'WORDPRESS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper4',
                'std'  => '100',
                'type'    => 'text',
            ),

            array(
                'name' => 'Process Box Settings',
                'desc' => 'Set up your process box on Home page',
                'id'   => $prefix . 'processsettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the process box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'processtitle',
                'std'  => 'OUR PROCESS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the process item title #1',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'processtitle1',
                'std'  => 'PLANNING',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item short description #1',
                'desc' => 'Insert the short description',
                'id'   => $prefix . 'processdesc1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item title #2',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'processtitle2',
                'std'  => 'DEVELOPING',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item short description #2',
                'desc' => 'Insert the short description',
                'id'   => $prefix . 'processdesc2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item title #3',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'processtitle3',
                'std'  => 'TESTING',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item short description #3',
                'desc' => 'Insert the short description',
                'id'   => $prefix . 'processdesc3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item title #4',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'processtitle4',
                'std'  => 'DELIVERING',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the process item short description #4',
                'desc' => 'Insert the short description',
                'id'   => $prefix . 'processdesc4',
                'std'  => '',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'gallery_metabox',
        'title'      => 'Gallery Options',
        'pages'      => array( 'gallery', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Client',
                'desc' => 'Insert the Client',
                'id'   => $prefix . 'gclient',
                'type' => 'text',
            ),
            array(
                'name' => 'Date',
                'desc' => 'Insert the Date',
                'id'   => $prefix . 'gdate',
                'type' => 'text',
            ),
            array(
                'name' => 'Tags',
                'desc' => 'Insert the Tags',
                'id'   => $prefix . 'gtags',
                'type' => 'text',
            ),

            array(
                'name' => 'Project external link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'glink',
                'type' => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'customblog_metabox',
        'title'      => 'Blog Options',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'show_on'    => array( 'key' => 'page-template', 'value' => array('template-blog.php','template-defaltblog.php'), ),
        'fields' => array(
            array(
                'name' => 'Posts Per Page',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'itemperpage',
                'std'  => '9',
                'type' => 'text',
            ),
            array(
                'name' => 'Sidebar style',
                'desc' => 'Select the sidebar style. Hide, Left or Right.',
                'id'   => $prefix . 'customblogsidebar',
                'std'  => 'no',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'No Sidebar', 'value' => 'no', ),
                    array( 'name' => 'Left Sidebar', 'value' => '2c-l-fixed', ),
                    array( 'name' => 'Right Sidebar', 'value' => '2c-r-fixed', ),
                ),
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'home_metabox',
        'title'      => 'Home Page Options',
        'pages'      => array( 'page', ), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'show_on'    => array( 'key' => 'page-template', 'value' => array('page-home.php'), ), // Specific post templates to display this metabox
        'fields' => array(
            array(
                'name' => 'Show or Hide Boxes on Home',
                'desc' => 'Select enable or disable to show or hide boxes on home',
                'id'   => $prefix . 'boxessettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Show The Services Box?',
                'desc' => 'Select enable to show the services box',
                'id'   => $prefix . 'serviceonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The About us Box?',
                'desc' => 'Select enable to show the about us box',
                'id'   => $prefix . 'aboutonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The Skills Box?',
                'desc' => 'Select enable to show the skills box',
                'id'   => $prefix . 'skillsonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The Facts Box?',
                'desc' => 'Select enable to show the facts box',
                'id'   => $prefix . 'factsonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The Works Box?',
                'desc' => 'Select enable to show the works box',
                'id'   => $prefix . 'worksonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The Testimonials Box?',
                'desc' => 'Select enable to show the testimonials box',
                'id'   => $prefix . 'testimonialsonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Show The Contacts Box?',
                'desc' => 'Select enable to show the contacts box',
                'id'   => $prefix . 'contactsonhome',
                'std'  => 'on',
                'type'    => 'select',
                'options' => array(
                    array( 'name' => 'Enable', 'value' => 'on', ),
                    array( 'name' => 'Disable', 'value' => 'off', ),
                ),
            ),

            array(
                'name' => 'Services Box Settings',
                'desc' => 'Set up your services box on Home page',
                'id'   => $prefix . 'sersettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the services box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtitle',
                'std'  => 'Our Service',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the services box description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'servdesc',
                'std'  => 'Services description here',
                'type'    => 'wysiwyg',
                'options' => array(    'textarea_rows' => 5, ),
            ),

            array(
                'name' => 'Insert the services box link',
                'desc' => 'Insert the link',
                'id'   => $prefix . 'servlink',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the services box link title',
                'desc' => 'Insert the link title',
                'id'   => $prefix . 'servlinktit',
                'std'  => 'More Details ...',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 1 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic1',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 1 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov1',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 1 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit1',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 2 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic2',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 2 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov2',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 2 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit2',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 3 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic3',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 3 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov3',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 3 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit3',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the service 4 Icon',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servic4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 4 Icon hover',
                'desc' => 'Insert the link or upload (Recommended size - 100px-100px)',
                'id'   => $prefix . 'servichov4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the service 4 Title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'servtit4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'About Box Settings',
                'desc' => 'Set up your about box on Home page',
                'id'   => $prefix . 'abautsettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the about box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'abouttitle',
                'std'  => 'ABOUT US',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about box sub title',
                'desc' => 'Insert the sub title',
                'id'   => $prefix . 'aboutsubtitle',
                'std'  => 'WHO WE ARE',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about box description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc',
                'std'  => 'About description here',
                'type'    => 'wysiwyg',
                'options' => array(    'textarea_rows' => 5, ),
            ),

            array(
                'name' => 'Insert the about member 1 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic1',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 2 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic2',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 3 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic3',
                'std'  => '',
                'type'    => 'file',
            ),
            array(
                'name' => 'Insert the about member 4 photo',
                'desc' => 'Insert the link or upload (Recommended size - 220px-220px)',
                'id'   => $prefix . 'aboutic4',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the about member 1 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 2 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 3 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 4 Name',
                'desc' => 'Insert the name',
                'id'   => $prefix . 'aboutname4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about member 1 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof1',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 2 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof2',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 3 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof3',
                'std'  => '',
                'type'    => 'text',
            ),
            array(
                'name' => 'Insert the about member 4 Prof',
                'desc' => 'Insert the prof',
                'id'   => $prefix . 'aboutprof4',
                'std'  => '',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the about member 1 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc1',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 2 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc2',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 3 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc3',
                'std'  => '',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Insert the about member 4 Description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'aboutdesc4',
                'std'  => '',
                'type'    => 'textarea',
            ),

            array(
                'name' => 'Skills Box Settings',
                'desc' => 'Set up your skills box on Home page',
                'id'   => $prefix . 'skillssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the skills box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle',
                'std'  => 'OUR SKILLS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle1',
                'std'  => 'PROGRAMMING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 1 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper1',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle2',
                'std'  => 'WEB DEVELOPING',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 2 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper2',
                'std'  => '70',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle3',
                'std'  => 'WEB DESIGN',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 3 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper3',
                'std'  => '90',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillstitle4',
                'std'  => 'WORDPRESS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the skills 4 Percent',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'skillsper4',
                'std'  => '100',
                'type'    => 'text',
            ),

            array(
                'name' => 'Facts Box Settings',
                'desc' => 'Set up your facts box on Home page',
                'id'   => $prefix . 'factssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the facts box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle',
                'std'  => 'HOW ABOUT SOME FUN FACTS ABOUT OUR AGENCY?',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the facts box bg image',
                'desc' => 'Insert the image',
                'id'   => $prefix . 'factsimage',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the fact 1 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle1',
                'std'  => 'Pizzas Ordered',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 2 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle2',
                'std'  => 'Clients Worked With',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 3 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle3',
                'std'  => 'Projects Completed',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 4 title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'factstitle4',
                'std'  => 'Magazines Published',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 1 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount1',
                'std'  => '520',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 2 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount2',
                'std'  => '90',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 3 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount3',
                'std'  => '129',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the fact 4 count',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'factscount4',
                'std'  => '20',
                'type'    => 'text',
            ),

            array(
                'name' => 'Testimonials Box Settings',
                'desc' => 'Set up your testimonials box on Home page',
                'id'   => $prefix . 'testimonialssettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the testimonial title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'testiminialstitle',
                'std'  => 'OUR TESTIMONIALS',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the testimonial bg',
                'desc' => 'Insert the bg',
                'id'   => $prefix . 'testiminialsbg',
                'std'  => '',
                'type'    => 'file',
            ),

            array(
                'name' => 'Insert the testimonials item in slider',
                'desc' => 'Insert the count',
                'id'   => $prefix . 'testiminialscount',
                'std'  => '3',
                'type'    => 'text',
            ),

            array(
                'name' => 'Contact Box Settings',
                'desc' => 'Set up your contact box on Home page',
                'id'   => $prefix . 'contactsettings',
                'type'    => 'title',
            ),

            array(
                'name' => 'Insert the contact box title',
                'desc' => 'Insert the title',
                'id'   => $prefix . 'contacttitle',
                'std'  => 'CONTACT US',
                'type'    => 'text',
            ),

            array(
                'name' => 'Insert the contact box description',
                'desc' => 'Insert the description',
                'id'   => $prefix . 'contactdesc',
                'std'  => 'Contact description here',
                'type'    => 'wysiwyg',
                'options' => array(    'textarea_rows' => 5, ),
            ),

            array(
                'name' => 'Insert the contact box MAP HTML code',
                'desc' => 'Insert the map code',
                'id'   => $prefix . 'contactmap',
                'std'  => '',
                'type'    => 'textarea_code',
            ),
        )
    );



	return $meta_boxes;
}

/**
 * Get image sizes for images
 * 
 * @return array
 */
function aletheme_get_images_sizes() {
	return array(

        'gallery' => array(
            array(
                'name'      => 'gallery-thumba',
                'width'     => 979,
                'height'    => 583,
                'crop'      => true,
            ),
            array(
                'name'      => 'gallery-mini',
                'width'     => 241,
                'height'    => 246,
                'crop'      => true,
            ),
            array(
                'name'      => 'gallery-big',
                'width'     => 486,
                'height'    => 246,
                'crop'      => true,
            ),
            array(
                'name'      => 'gallery-filter',
                'width'     => 361,
                'height'    => 272,
                'crop'      => true,
            ),

            array(
                'name'      => 'gallery-drop',
                'width'     => 300,
                'height'    => 273,
                'crop'      => true,
            ),
        ),
        'post' => array(
            array(
                'name'      => 'post-thumba',
                'width'     => 475,
                'height'    => 295,
                'crop'      => true,
            ),
            array(
                'name'      => 'post-box',
                'width'     => 638,
                'height'    => 400,
                'crop'      => true,
            ),
            array(
                'name'      => 'post-mini',
                'width'     => 213,
                'height'    => 159,
                'crop'      => true,
            ),
            array(
                'name'      => 'post-blog',
                'width'     => 480,
                'height'    => 440,
                'crop'      => true,
            ),
            array(
                'name'      => 'post-bigblog',
                'width'     => 980,
                'height'    => 540,
                'crop'      => true,
            ),
        ),
        'testimonials' => array(
            array(
                'name'      => 'testimonials-mini',
                'width'     => 220,
                'height'    => 220,
                'crop'      => true,
            ),
            array(
                'name'      => 'testimonials-normal',
                'width'     => 487,
                'height'    => 303,
                'crop'      => true,
            ),
        ),
    );
}

/**
 * Add post types that are used in the theme 
 * 
 * @return array
 */
function aletheme_get_post_types() {
	return array(
        'gallery' => array(
            'config' => array(
                'public' => true,
                'menu_position' => 20,
                'has_archive'   => true,
                'supports'=> array(
                    'title',
                    'editor',
                    'thumbnail',
                ),
                'show_in_nav_menus'=> true,
            ),
            'singular' => 'Gallery',
            'multiple' => 'Galleries',
            'columns'    => array(
                'first_image',
            )
        ),

        'testimonials' => array(
            'config' => array(
                'public' => true,
                'menu_position' => 20,
                'has_archive'   => true,
                'supports'=> array(
                    'title',
                    'editor',
                    'thumbnail',
                ),
                'show_in_nav_menus'=> true,
            ),
            'singular' => 'Testimonial',
            'multiple' => 'Testimonials',
            'columns'    => array(
                'first_image',
            )
        ),
    );
}

/**
 * Add taxonomies that are used in theme
 * 
 * @return array
 */
function aletheme_get_taxonomies() {
	return array(

        'gallery-category'    => array(
            'for'        => array('gallery'),
            'config'    => array(
                'sort'        => true,
                'args'        => array('orderby' => 'term_order'),
                'hierarchical' => true,
            ),
            'singular'    => 'Gallery Category',
            'multiple'    => 'Gallery Categories',
        ),
    );
}

/**
 * Add post formats that are used in theme
 * 
 * @return array
 */
function aletheme_get_post_formats() {
	return array('gallery','video');
}

/**
 * Get sidebars list
 * 
 * @return array
 */
function aletheme_get_sidebars() {
	$sidebars = array('Woo Commerce');
	return $sidebars;
}

/**
 * Predefine custom sliders
 * @return array
 */
function aletheme_get_sliders() {
	return array(
		'sneak-peek' => array(
			'title'		=> 'Sneak Peek',
		),
	);
}

/**
 * Post types where metaboxes should show
 * 
 * @return array
 */
function aletheme_get_post_types_with_gallery() {
	return array('gallery','post');
}

/**
 * Add custom fields for media attachments
 * @return array
 */
function aletheme_media_custom_fields() {
	return array();
}