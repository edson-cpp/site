<?php
/*
  * Template name: Home
  * */
if (isset($_POST['contact'])) {
    $error = ale_send_contact($_POST['contact']);
}
get_header(); ?>

<?php if(ale_get_meta('serviceonhome')=='on') { ?>
    <!-- Our Service -->
    <section class="our-service">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('servtitle'); ?></span><span>]</span>
            </div>

            <div class="text">
                <p>
                    <?php echo do_shortcode(ale_get_meta('servdesc')); ?>
                </p>
                <a href="<?php echo ale_get_meta('servlink'); ?>"><?php echo ale_get_meta('servlinktit'); ?></a>
            </div>

            <div class="icons cf">
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic1" <?php if(ale_get_meta('servic1')){ echo 'style="background-image:url('.ale_get_meta('servic1').');"'; } ?>>
                            <div class="ic1-w" <?php if(ale_get_meta('servichov1')){ echo 'style="background-image:url('.ale_get_meta('servichov1').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit1'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic2" <?php if(ale_get_meta('servic2')){ echo 'style="background-image:url('.ale_get_meta('servic2').');"'; } ?>>
                            <div class="ic2-w" <?php if(ale_get_meta('servichov2')){ echo 'style="background-image:url('.ale_get_meta('servichov2').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit2'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic3" <?php if(ale_get_meta('servic3')){ echo 'style="background-image:url('.ale_get_meta('servic3').');"'; } ?>>
                            <div class="ic3-w" <?php if(ale_get_meta('servichov3')){ echo 'style="background-image:url('.ale_get_meta('servichov3').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit3'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic4" <?php if(ale_get_meta('servic4')){ echo 'style="background-image:url('.ale_get_meta('servic4').');"'; } ?>>
                            <div class="ic4-w" <?php if(ale_get_meta('servichov4')){ echo 'style="background-image:url('.ale_get_meta('servichov4').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit4'); ?></p>
                </div>
            </div>
        </div>
    </section>
<?php } ?>

<?php if(ale_get_meta('aboutonhome')=='on') { ?>
    <!-- About Us -->
    <section class="about-us">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('abouttitle'); ?></span><span>]</span>
            </div>

            <div class="text">
                <span><?php echo ale_get_meta('aboutsubtitle'); ?></span>
                <p>
                    <?php echo ale_get_meta('aboutdesc'); ?>
                </p>
            </div>

            <div class="peoples cf">
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc1'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic1'); ?>" alt="<?php echo ale_get_meta('aboutname1'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname1'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof1'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc2'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic2'); ?>" alt="<?php echo ale_get_meta('aboutname2'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname2'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof2'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc3'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic3'); ?>" alt="<?php echo ale_get_meta('aboutname3'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname3'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof3'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc4'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic4'); ?>" alt="<?php echo ale_get_meta('aboutname4'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname4'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof4'); ?></p>
                </div>
            </div>

        </div>
    </section>
<?php } ?>

<?php if(ale_get_meta('skillsonhome')=='on') { ?>
    <!-- Our Skills -->
    <section class="our-skills">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('skillstitle'); ?></span><span>]</span>
            </div>

            <div class="prog-bars">
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle1'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper1'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle2'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper2'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle3'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper3'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle4'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper4'); ?>%;" class="progress"></div>
                    </div>
                </div>
            </div>

        </div>
    </section>
<?php } ?>

<?php if(ale_get_meta('factsonhome')=='on') { ?>
    <!-- Some Facts -->
    <div class="some-facts" <?php if (ale_get_meta('factsimage')){ echo 'style="background-image:url('.ale_get_meta('factsimage').');"';} ?>>
        <div class="pattern"></div>

        <div class="content">
            <div class="center-align">
                <span><?php echo ale_get_meta('factstitle'); ?></span>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount1'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle1'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount2'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle2'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount3'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle3'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount4'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle4'); ?></p>
                </div>

            </div>
        </div>

    </div>
<?php } ?>

<?php if(ale_get_meta('worksonhome')=='on') { ?>
    <!-- Our Works -->
    <section class="our-works">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Our Works','aletheme'); ?></span><span>]</span>
            </div>

            <div id="filters" class="menu">
                <a data-filter="*" class="active"><?php _e('All', 'aletheme')?></a>
                <?php $args = array(
                    'type'                     => 'gallery',
                    'child_of'                 => 0,
                    'parent'                   => '',
                    'orderby'                  => 'name',
                    'order'                    => 'ASC',
                    'hide_empty'               => 1,
                    'hierarchical'             => 1,
                    'exclude'                  => '',
                    'include'                  => '',
                    'number'                   => '',
                    'taxonomy'                 => 'gallery-category',
                    'pad_counts'               => false );

                $categories = get_categories( $args );

                foreach($categories as $cat){
                    echo '<a href="#" data-filter=".'.$cat->slug.'">'.$cat->name.'</a>';
                }
                ?>
            </div>

            <div id="galcontainer" class="gallery cf">

                <?php query_posts('&post_type=gallery&posts_per_page=9'); ?>
                <?php $g_counter=0; if (have_posts()) : while (have_posts()) : the_post(); $g_counter++; ?>
                    <div class="element <?php $terms = get_the_terms($post->ID, 'gallery-category'); foreach($terms as $itcat) { echo $itcat->slug.' ';} ?> <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") { echo "col-6"; } else {echo "col-3";} ?>">
                        <a href="<?php the_permalink(); ?>">
                            <div class="outlines">
                                <div class="triangle"><p>+</p></div>
                            </div>
                            <div class="mask"></div>
                            <span><?php the_title(); ?></span>

                            <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") {
                                echo get_the_post_thumbnail($post->ID,'gallery-big');
                            } else {
                                echo get_the_post_thumbnail($post->ID,'gallery-mini');
                            } ?>
                        </a>
                    </div>
                <?php endwhile; else: ?>
                    <?php ale_part('notfound')?>
                <?php endif; wp_reset_query(); ?>
            </div>
            <div class="view"><a href="<?php echo home_url(); ?>/gallery"><?php _e('View all galleries...','aletheme'); ?></a></div>

        </div>
    </section>
<?php } ?>

<?php if(ale_get_meta('testimonialsonhome')=='on') { ?>
    <!-- Testimonials -->
    <div class="testimonials" <?php if(ale_get_meta('testiminialsbg')){ echo 'style="background-image:url('.ale_get_meta('testiminialsbg').');"'; } ?>>
        <div class="pattern"></div>

        <div class="content">
            <div class="center-align">
                <span><a href="<?php echo home_url(); ?>/testimonials"><?php echo ale_get_meta('testiminialstitle'); ?></a></span>
                <ul id="peoples-testimonials">
                    <?php $testyperpage = ale_get_meta('testiminialscount'); query_posts('&post_type=testimonials&posts_per_page='.$testyperpage); ?>
                    <?php $t_counter=0; if (have_posts()) : while (have_posts()) : the_post(); $t_counter++; ?>
                    <li class="<?php if($t_counter==1){ echo "active"; } ?>">
                        <div class="col-4">
                            <a class="nav left"></a>
                            <a class="nav right"></a>

                            <div class="people">
                                <?php echo get_the_post_thumbnail($post->ID,'testimonials-mini'); ?>
                            </div>
                        </div>
                        <div class="col-10">
                            <?php the_content(); ?>
                        </div>

                    </li>
                    <?php endwhile; else: ?>
                        <?php ale_part('notfound')?>
                    <?php endif; wp_reset_query(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php } ?>

<?php if(ale_get_meta('contactsonhome')=='on') { ?>
    <section class="contact-us">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('contacttitle'); ?></span><span>]</span>
            </div>
            <div class="text">
                <p><?php echo ale_get_meta('contactdesc'); ?></p>
            </div>
            <div class="map">
                <?php echo str_replace('&','&amp;',ale_get_meta('contactmap')); ?>
            </div>
        </div>
        <a name="success"></a>
        <div class="background">
            <div class="center-align">

                    <form method="post" id="contact-form" action="<?php the_permalink();?>">
                        <?php if (isset($_GET['success'])) : ?>
                            <p class="success"><?php _e('Thank you for your message!', 'aletheme')?></p>
                        <?php endif; ?>
                        <?php if (isset($error) && isset($error['msg'])) : ?>
                            <p class="error"><?php echo $error['msg']?></p>
                        <?php endif; ?>
                    <div class="col-6">
                        <input name="contact[name]" type="text" placeholder="<?php _e('Name','aletheme') ?> *" value="<?php echo isset($_POST['contact']['name']) ? $_POST['contact']['name'] : ''?>" required="required"/>
                        <input name="contact[email]" type="email" placeholder="<?php _e('E-mail','aletheme') ?> *" value="<?php echo isset($_POST['contact']['email']) ? $_POST['contact']['email'] : ''?>" required="required"/>
                        <input name="contact[how]" type="text" placeholder="<?php _e('Subject','aletheme') ?> *"  value="<?php echo isset($_POST['contact']['how']) ? $_POST['contact']['how'] : ''?>" required="required"/>
                    </div>

                    <div class="col-6">
                        <textarea class="right" name="contact[message]"  placeholder="<?php _e('Comment','aletheme') ?> *"  required="required"></textarea>
                        <input type="submit" class="right submit" value=""/>
                        <?php wp_nonce_field() ?>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php } ?>

<?php get_footer(); ?>

