<?php get_header(); ?>

    <section class="blog">
    <div class="center-align">
        <div class="caption">
            <div class="line left"></div>
            <div class="line right"></div>
            <span>[</span><span class="cap"><?php _e('Our Blog','aletheme'); ?></span><span>]</span>
        </div>
    </div>


    <div class="center-align main">

        <?php if(ale_get_option('sidebarblog')=='2c-l-fixed'){
            ale_part('blog-left-sidebar');
        } ?>

    <div class="<?php if(ale_get_option('sidebarblog')=='2c-l-fixed' or ale_get_option('sidebarblog')=='2c-r-fixed'){ ?>col-8 content<?php } ?> content2" <?php if(ale_get_option('sidebarblog')=='2c-l-fixed'){ ?> style="padding-left:15px;" <?php } elseif(ale_get_option('sidebarblog')=='2c-r-fixed'){?> style="padding-right:15px;" <?php } ?>>

        <?php $p_counter=0; if (have_posts()) : while (have_posts()) : the_post(); $p_counter++; ?>

        <div class="<?php if($p_counter==3 or $p_counter==6 or $p_counter==9){ echo "post-big col-12";} else { echo "post-small col-6";} ?>">
            <a href="<?php the_permalink(); ?>">
                <span class="mask"></span>
                <p><?php the_title(); ?></p>
                <p class="date"><?php echo get_the_date(); ?></p>
                <span class="icon"></span>
                <?php if($p_counter==3 or $p_counter==6 or $p_counter==9){ echo get_the_post_thumbnail($post->ID,'post-bigblog'); } else {echo get_the_post_thumbnail($post->ID,'post-blog');} ?>
            </a>
            <!-- -->
            <div class="caption"><?php the_title(); ?></div>
            <div class="date"><?php echo get_the_date(); ?></div>
            <p class="text">
                <?php if($p_counter==3 or $p_counter==6 or $p_counter==9){ echo ale_trim_excerpt(32); } else {echo ale_trim_excerpt(16);} ?>
            </p>
            <a class="href" href="<?php the_permalink(); ?>"><?php _e('Take a look','aletheme'); ?></a>
            <ul class="info">
                <li class="views"><span></span>  <?php echo ale_postviews($post->ID, 'display'); ?></li>
                <li class="comments"><span></span> <?php echo get_comments_number($post->ID); ?></li>
            </ul>
        </div>

        <?php endwhile; else: ?>
            <?php ale_part('notfound')?>
        <?php endif; ?>

        <div class="cf"></div>
        <div class="pagination">
            <?php
            $big = 999999999;
            echo paginate_links( array(
                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format' => '?paged=%#%',
                'show_all'     => False,
                'end_size'     => 1,
                'mid_size'     => 2,
                'prev_next'    => False,
                'type'         => 'plain',
                'add_args'     => False,
                'prev_text' => '',
                'next_text' => '',
                'current' => max( 1, get_query_var('paged') ),
                'total' => $wp_query->max_num_pages
            ) ); ?>
        </div>

    </div>

        <?php if(ale_get_option('sidebarblog')=='2c-r-fixed') {
            ale_part('blog-right-sidebar');
        } ?>

    </div>
    </section>

<?php get_footer(); ?>