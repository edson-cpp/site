<?php
/**
 * Template Name: Template About
 */
get_header(); ?>

    <!-- About Us -->
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <section class="about-us about">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
            </div>

            <div class="text">
                <span><?php echo ale_get_meta('aboutsubtitle'); ?></span>
                <?php the_content(); ?>
            </div>

            <div class="peoples cf">
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc1'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic1'); ?>" alt="<?php echo ale_get_meta('aboutname1'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname1'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof1'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc2'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic2'); ?>" alt="<?php echo ale_get_meta('aboutname2'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname2'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof2'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc3'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic3'); ?>" alt="<?php echo ale_get_meta('aboutname3'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname3'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof3'); ?></p>
                </div>
                <!-- -->
                <div class="col-3">
                    <a href="" class="people">
                        <div class="mask">
                            <p>
                                <?php echo ale_get_meta('aboutdesc4'); ?>
                            </p>
                        </div>
                        <img src="<?php echo ale_get_meta('aboutic4'); ?>" alt="<?php echo ale_get_meta('aboutname4'); ?>"/>
                    </a>

                    <span><?php echo ale_get_meta('aboutname4'); ?></span>
                    <p><?php echo ale_get_meta('aboutprof4'); ?></p>
                </div>
            </div>

        </div>
    </section>


    <!-- Our Skills -->
    <section class="our-skills about">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('skillstitle'); ?></span><span>]</span>
            </div>

            <div class="prog-bars">
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle1'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper1'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle2'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper2'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle3'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper3'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle4'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper4'); ?>%;" class="progress"></div>
                    </div>
                </div>
            </div>

        </div>
    </section>


    <!-- Some Facts -->
    <div class="some-facts" <?php if (ale_get_meta('factsimage')){ echo 'style="background-image:url('.ale_get_meta('factsimage').');"';} ?>>
        <div class="pattern"></div>

        <div class="content">
            <div class="center-align">
                <span><?php echo ale_get_meta('factstitle'); ?></span>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount1'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle1'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount2'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle2'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount3'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle3'); ?></p>
                </div>
                <!--  -->
                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="<?php echo ale_get_meta('factscount4'); ?>">
                        <span class="percent"></span>
                    </div>
                    <p><?php echo ale_get_meta('factstitle4'); ?></p>
                </div>

            </div>
        </div>

    </div>
    <?php endwhile; else: ?>
        <?php ale_part('notfound')?>
    <?php endif; ?>
<?php get_footer(); ?>