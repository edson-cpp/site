<?php
/**
 * Template Name: Template Service
 */
get_header(); ?>
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <!-- Our Service -->
    <section class="our-service service">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
            </div>

            <div class="text">
                <?php the_content(); ?>
            </div>

            <div class="icons cf">
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic1" <?php if(ale_get_meta('servic1')){ echo 'style="background-image:url('.ale_get_meta('servic1').');"'; } ?>>
                            <div class="ic1-w" <?php if(ale_get_meta('servichov1')){ echo 'style="background-image:url('.ale_get_meta('servichov1').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit1'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('servdesc1'); ?>
                        </p>
                    </div>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic2" <?php if(ale_get_meta('servic2')){ echo 'style="background-image:url('.ale_get_meta('servic2').');"'; } ?>>
                            <div class="ic2-w" <?php if(ale_get_meta('servichov2')){ echo 'style="background-image:url('.ale_get_meta('servichov2').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit2'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('servdesc2'); ?>
                        </p>
                    </div>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic3" <?php if(ale_get_meta('servic3')){ echo 'style="background-image:url('.ale_get_meta('servic3').');"'; } ?>>
                            <div class="ic3-w" <?php if(ale_get_meta('servichov3')){ echo 'style="background-image:url('.ale_get_meta('servichov3').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit3'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('servdesc3'); ?>
                        </p>
                    </div>
                </div>
                <!--  -->
                <div class="col-3">
                    <a class="icon">
                        <div class="ic4" <?php if(ale_get_meta('servic4')){ echo 'style="background-image:url('.ale_get_meta('servic4').');"'; } ?>>
                            <div class="ic4-w" <?php if(ale_get_meta('servichov4')){ echo 'style="background-image:url('.ale_get_meta('servichov4').');"'; } ?>></div>
                        </div>
                    </a>
                    <p class="caption"><?php echo ale_get_meta('servtit4'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('servdesc4'); ?>
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <?php endwhile; else: ?>
        <?php ale_part('notfound')?>
    <?php endif; ?>

    <!-- Why Chose Us -->
    <div class="why-choose-us">
        <div class="background">
            <div class="center-align">

                <div class="col-5">
                    <!-- Caption -->
                    <div class="caption"> <p><?php echo ale_get_meta('toggletit'); ?></p> </div>

                    <!-- Text -->
                    <ul id="why-choose">
                        <li>
                            <div class="icon"></div>
                            <div class="icon2"></div>
                            <a><?php echo ale_get_meta('toggletit1'); ?></a>
                            <p class="content">
                                <?php echo ale_get_meta('toggledesc1'); ?>
                            </p>
                        </li>

                        <li>
                            <div class="icon"></div>
                            <div class="icon2"></div>
                            <a><?php echo ale_get_meta('toggletit2'); ?></a>
                            <p class="content">
                                <?php echo ale_get_meta('toggledesc2'); ?>
                            </p>
                        </li>

                        <li>
                            <div class="icon"></div>
                            <div class="icon2"></div>
                            <a><?php echo ale_get_meta('toggletit3'); ?></a>
                            <p class="content">
                                <?php echo ale_get_meta('toggledesc3'); ?>
                            </p>
                        </li>

                        <li>
                            <div class="icon"></div>
                            <div class="icon2"></div>
                            <a><?php echo ale_get_meta('toggletit4'); ?></a>
                            <p class="content">
                                <?php echo ale_get_meta('toggledesc4'); ?>
                            </p>
                        </li>

                    </ul>
                </div>

                <!-- Scrollable Here -->

                <div class="col-6 news">
                    <!-- Caprion -->
                    <div class="caption">
                        <p><?php _e('Recent from Blog','aletheme'); ?>  <a class="next browse right"></a> <a class="prev browse left"></a> </p>
                    </div>

                    <!-- LIST -->
                    <div class="scrollable" id="scrollable">
                        <div class="items">
                            <?php wp_reset_query(); query_posts('&post_type=post&posts_per_page=4'); ?>
                            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="item">
                                <a href="<?php the_permalink(); ?>">
                                    <?php echo get_the_post_thumbnail($post->ID,'post-mini'); ?>
                                </a>
                                <!-- -->
                                <a href="<?php the_permalink(); ?>" class="caption"><?php the_title(); ?></a>
                                <span><?php echo get_the_date(); ?> / <?php echo get_comments_number($post->ID); ?> <?php _e('Comments','aletheme'); ?></span>
                                <p>
                                    <?php echo ale_trim_excerpt(15); ?>
                                </p>
                            </div>
                            <?php endwhile; else: ?>
                                <?php ale_part('notfound')?>
                            <?php endif;wp_reset_query(); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Our Skills -->
    <section class="our-skills service">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php echo ale_get_meta('skillstitle'); ?></span><span>]</span>
            </div>

            <div class="prog-bars">
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle1'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper1'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle2'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper2'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle3'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper3'); ?>%;" class="progress"></div>
                    </div>
                </div>
                <!--  -->
                <div class="col-6">
                    <div class="bar">
                        <span><?php echo ale_get_meta('skillstitle4'); ?></span>
                        <div style="width: <?php echo ale_get_meta('skillsper4'); ?>%;" class="progress"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Process -->
    <section class="our-process">
        <div class="background">
            <div class="center-align">
                <div class="caption">
                    <div class="line left"></div>
                    <div class="line right"></div>
                    <span>[</span><span class="cap"><?php echo ale_get_meta('processtitle'); ?></span><span>]</span>
                </div>

                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="25"><p>1</p></div>

                    <p class="caption"><?php echo ale_get_meta('processtitle1'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('processdesc1'); ?>
                        </p>
                    </div>
                </div>

                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="50"><p>2</p></div>

                    <p class="caption"><?php echo ale_get_meta('processtitle2'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('processdesc2'); ?>
                        </p>
                    </div>
                </div>

                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="75"><p>3</p></div>

                    <p class="caption"><?php echo ale_get_meta('processtitle3'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('processdesc3'); ?>
                        </p>
                    </div>
                </div>

                <div class="col-3">
                    <div class="chart" data-percent="0" data-update="100"><p>4</p></div>

                    <p class="caption"><?php echo ale_get_meta('processtitle4'); ?></p>
                    <div class="text">
                        <p>
                            <?php echo ale_get_meta('processdesc4'); ?>
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </section>


<?php get_footer(); ?>