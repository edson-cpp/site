<?php
/**
 * Template Name: Gallery with Filter 2
 */
get_header(); ?>

    <!-- Our Works -->
    <section class="portfolio2">

        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
            </div>

            <div id="filters" class="menu">
                <a data-filter="*" class="active"><?php _e('All Works', 'aletheme')?></a>
                <?php $args = array(
                    'type'                     => 'gallery',
                    'child_of'                 => 0,
                    'parent'                   => '',
                    'orderby'                  => 'name',
                    'order'                    => 'ASC',
                    'hide_empty'               => 1,
                    'hierarchical'             => 1,
                    'exclude'                  => '',
                    'include'                  => '',
                    'number'                   => '',
                    'taxonomy'                 => 'gallery-category',
                    'pad_counts'               => false );

                $categories = get_categories( $args );

                foreach($categories as $cat){
                    echo '<a href="#" data-filter=".'.$cat->slug.'">'.$cat->name.'</a>';
                }
                ?>
            </div>
        </div>

        <div id="galcontainer" class="gallery">
            <?php query_posts('&post_type=gallery&posts_per_page=-1'); ?>
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="element <?php $terms = get_the_terms($post->ID, 'gallery-category'); foreach($terms as $itcat) { echo $itcat->slug.' ';} ?> col-2i5">
                    <a href="<?php the_permalink(); ?>">
                        <span class="mask"></span>
                        <span class="outlines"></span>
                        <p><?php the_title(); ?></p>
                        <span class="icon"></span>
                        <?php echo get_the_post_thumbnail($post->ID,'gallery-filter'); ?>
                    </a>
                </div>
            <?php endwhile; else: ?>
                <?php ale_part('notfound')?>
            <?php endif; ?>
        </div>
    </section>

<?php get_footer(); ?>