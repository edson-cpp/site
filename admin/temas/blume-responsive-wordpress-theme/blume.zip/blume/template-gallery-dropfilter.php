<?php
/**
 * Template Name: Gallery with Filter 3
 */
get_header(); ?>

    <!-- Our Works -->
    <section class="portfolio3">

        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
            </div>
            <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $pag_query = new WP_Query( '&post_type=gallery&paged='.$paged);
            ?>
            <div class="head-line">
                <span><?php _e('page','aletheme');?> <?php echo $paged; ?> <?php _e('of','aletheme');?> <?php echo $pag_query->max_num_pages; ?></span>

                <div class="filter">
                    <a>Filter by <span class="tria"></span> </a>
                    <ul id="filters">
                        <li><a data-filter="*" class="active"><?php _e('All Works', 'aletheme')?></a></li>
                        <?php $args = array(
                            'type'                     => 'gallery',
                            'child_of'                 => 0,
                            'parent'                   => '',
                            'orderby'                  => 'name',
                            'order'                    => 'ASC',
                            'hide_empty'               => 1,
                            'hierarchical'             => 1,
                            'exclude'                  => '',
                            'include'                  => '',
                            'number'                   => '',
                            'taxonomy'                 => 'gallery-category',
                            'pad_counts'               => false );

                        $categories = get_categories( $args );

                        foreach($categories as $cat){
                            echo '<li><a href="#" data-filter=".'.$cat->slug.'">'.$cat->name.'</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>

            <div id="galcontainer"  class="gallery">
                <?php if ($pag_query->have_posts()) : while ($pag_query->have_posts()) : $pag_query->the_post(); ?>
                <div class="element <?php $terms = get_the_terms($post->ID, 'gallery-category'); foreach($terms as $itcat) { echo $itcat->slug.' ';} ?> col-4">
                    <a href="<?php the_permalink(); ?>">
                        <span class="mask"></span>
                        <span class="outlines"></span>
                        <p><?php the_title(); ?></p>
                        <span class="icon"></span>
                        <?php echo get_the_post_thumbnail($post->ID,'gallery-drop'); ?>
                    </a>

                    <div class="info">
                        <p class="caption"><?php the_title(); ?></p>
                        <p class="category"><?php $terms = get_the_terms($post->ID, 'gallery-category'); foreach($terms as $itcat) { echo $itcat->name.' ';} ?></p>
                    </div>
                </div>
                <?php endwhile; else: ?>
                    <?php ale_part('notfound')?>
                <?php endif; ?>
            </div>
        </div>

        <div class="pag">

        </div>

        <div class="pagination">
            <?php
            $big = 999999999;
            echo paginate_links( array(
                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format' => '?paged=%#%',
                'show_all'     => False,
                'end_size'     => 1,
                'mid_size'     => 2,
                'prev_next'    => False,
                'type'         => 'plain',
                'add_args'     => False,
                'prev_text' => '',
                'next_text' => '',
                'current' => max( 1, get_query_var('paged') ),
                'total' => $pag_query->max_num_pages
            ) ); ?>
        </div>

    </section>

<?php get_footer(); ?>