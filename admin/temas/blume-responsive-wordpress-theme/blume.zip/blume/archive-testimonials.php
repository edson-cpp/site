<?php get_header(); ?>

    <!-- Content Testimonials -->
    <section class="testimonials-page">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Testimonials','aletheme'); ?></span><span>]</span>
            </div>

            <ul id="post" class="testimonials-list">
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <li class="post">
                    <div class="hover">
                        <div class="name"><span><?php the_title(); ?></span></div>
                        <div class="text">
                            <?php the_content(); ?>
                        </div>
                        <ul class="soc">
                            <?php if(ale_get_meta('tesinst')){ ?><li class="instagram"><a href="<?php echo ale_get_meta('tesinst') ?>" rel="external"></a></li><?php } ?>
                            <?php if(ale_get_meta('tesflickr')){ ?><li class="flickr"><a href="<?php echo ale_get_meta('tesflickr') ?>" rel="external"></a></li><?php } ?>
                            <?php if(ale_get_meta('tespint')){ ?><li class="pinterest"><a href="<?php echo ale_get_meta('tespint') ?>" rel="external"></a></li><?php } ?>
                            <?php if(ale_get_meta('testwi')){ ?><li class="twitter"><a href="<?php echo ale_get_meta('testwi') ?>" rel="external"></a></li><?php } ?>
                            <?php if(ale_get_meta('tesfb')){ ?><li class="facebook"><a href="<?php echo ale_get_meta('tesfb') ?>" rel="external"></a></li><?php } ?>
                        </ul>
                    </div>
                    <?php echo get_the_post_thumbnail($post->ID,'testimonials-normal') ?>
                </li>
                <?php endwhile; else: ?>
                    <?php ale_part('notfound')?>
                <?php endif; ?>
            </ul>

            <?php global $wp_query; if($wp_query->max_num_pages > 1){ ?>
            <div class="load" id="pbd-alp-load-posts"><a><?php _e('Load More','aletheme'); ?><span></span></a></div>
            <?php } ?>

        </div>
    </section>

<?php get_footer(); ?>