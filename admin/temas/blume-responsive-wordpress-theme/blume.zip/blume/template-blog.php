<?php
/*
*  Template name: Blog 2
*/
get_header(); $blog_page_id = $post->ID; ?>

    <section class="blog">
    <div class="center-align">
        <div class="caption">
            <div class="line left"></div>
            <div class="line right"></div>
            <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
        </div>
    </div>

    <div class="center-align main">
        <?php if(ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-l-fixed'){
            ale_part('blog-left-sidebar');
        } ?>

        <!-- Content -->
        <div class="<?php if(ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-l-fixed' or ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-r-fixed'){ ?>col-8 <?php } ?> content" <?php if(ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-l-fixed'){ ?> style="padding-left:15px;" <?php } elseif(ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-r-fixed'){?> style="padding-right:15px;" <?php } ?>>
            <?php
            if(ale_get_meta('itemperpage','true',$blog_page_id)){
                $perpageitems = ale_get_meta('itemperpage','true',$blog_page_id);
            } else {
                $perpageitems="-1";
            }

            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

            $pag_query = new WP_Query( '&post_type=post&posts_per_page='.$perpageitems.'&paged='.$paged);

            if ($pag_query->have_posts()) : while ($pag_query->have_posts()) : $pag_query->the_post(); ?>
            <div class="post">
                <?php if (has_post_format('gallery')) { ?>
                    <div class="gallery-img cf">
                        <div class="items cf">
                            <?php foreach(ale_get_attached_images() as $image):?>
                                <div><?php echo wp_get_attachment_image($image->ID, 'post-bigblog')?></div>
                            <?php endforeach;?>
                        </div>

                        <a class="prev"></a>
                        <a class="next"></a>

                        <span class="info">
                            <a>
                                <?php _e('posted BY','aletheme'); ?> <?php echo get_the_author(); ?> <?php _e('ON','aletheme'); ?> <?php echo get_the_date(); ?> / <?php echo get_comments_number(); ?> <?php _e('COMMENTS','aletheme'); ?>
                                <span class="icon"></span>
                            </a>
                        </span>
                    </div>
                <?php } elseif (has_post_format('video')){ ?>
                    <div class="video">
                        <?php echo ale_create_wp_embed_player(ale_get_meta('videopostlink')); ?>

                        <span class="info">
                            <a>
                                <?php _e('posted BY','aletheme'); ?> <?php echo get_the_author(); ?> <?php _e('ON','aletheme'); ?> <?php echo get_the_date(); ?> / <?php echo get_comments_number(); ?> <?php _e('COMMENTS','aletheme'); ?>
                                <span class="icon"></span>
                            </a>
                        </span>
                    </div>
                <?php } else {?>
                    <div class="img">
                        <?php echo get_the_post_thumbnail($post->ID,'post-bigblog'); ?>
                        <span class="info">
                                <a>
                                    <?php _e('posted BY','aletheme'); ?> <?php echo get_the_author(); ?> <?php _e('ON','aletheme'); ?> <?php echo get_the_date(); ?> / <?php echo get_comments_number(); ?> <?php _e('COMMENTS','aletheme'); ?>
                                    <span class="icon"></span>
                                </a>
                            </span>
                    </div>
                <?php } ?>
                <div class="caption">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </div>

                <div class="text">
                    <?php echo ale_trim_excerpt(30); ?>
                </div>

                <div class="href"><a href="<?php the_permalink(); ?>"><?php _e('Take a look','aletheme'); ?></a></div>
            </div>

            <?php endwhile; else: ?>
                <?php ale_part('notfound')?>
            <?php endif; ?>
            <div class="cf"></div>
            <div class="pagination">
                <?php
                $big = 999999999;
                echo paginate_links( array(
                    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    'format' => '?paged=%#%',
                    'show_all'     => False,
                    'end_size'     => 1,
                    'mid_size'     => 2,
                    'prev_next'    => False,
                    'type'         => 'plain',
                    'add_args'     => False,
                    'prev_text' => '',
                    'next_text' => '',
                    'current' => max( 1, get_query_var('paged') ),
                    'total' => $pag_query->max_num_pages
                ) ); ?>
            </div>

        </div>

        <?php if(ale_get_meta('customblogsidebar','true',$blog_page_id)=='2c-r-fixed') {
            ale_part('blog-right-sidebar');
        } ?>

    </div>
    </section>

<?php get_footer(); ?>