<?php get_header(); ?>
    <section class="about-us about">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Error 404','aletheme'); ?></span><span>]</span>
            </div>

            <div class="text">
                <h1><?php _e('Error, Page not found','aletheme'); ?></h1>
                <p><?php _e('Sorry, but the page you\'re looking for has not found. Try checking the URL for errors, then hit the refresh<br /> button on your browser.','aletheme'); ?></p>
                <p>
                    <a href="<?php echo home_url();?>" class="gohomebut"><?php _e('Return to the homepage','aletheme'); ?></a>
                </p>
            </div>
        </div>
    </section>
<?php get_footer(); ?>