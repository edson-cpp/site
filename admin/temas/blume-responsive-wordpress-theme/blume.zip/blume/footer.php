    <footer>
        <div class="line-1 cf">
            <div class="center-align cf">
                <div class="col-6">
                    <span><?php echo ale_get_option('footnavtitle'); ?>:</span>
                </div>

                <div class="col-6">
                    <span><?php echo ale_get_option('footcontitle'); ?>:</span>
                </div>
            </div>
        </div>

        <div class="line-2 cf">
            <div class="center-align cf">

                <div class="col-6">
                    <?php
                    if ( has_nav_menu( 'footer_menu' ) ) {
                        wp_nav_menu(array(
                            'theme_location'=> 'footer_menu',
                            'menu'			=> 'Footer Menu',
                            'menu_class'	=> 'nav',
                            'walker'		=> new Aletheme_Nav_Walker(),
                            'container'		=> '',
                        ));
                    }
                    ?>
                </div>

                <div class="col-6 map">

                    <div class="col-6">
                        <span><?php echo ale_get_option('footcolonetitle'); ?></span>
                        <ul>
                            <li><?php echo ale_get_option('phone1'); ?></li>
                            <li><?php echo ale_get_option('phone2'); ?></li>
                            <li><?php echo ale_get_option('email1'); ?></li>
                            <li><?php echo ale_get_option('address1'); ?></li>
                        </ul>

                    </div>


                    <div class="col-6">
                        <span><?php echo ale_get_option('footcoltwotitle'); ?></span>
                        <ul>
                            <li><?php echo ale_get_option('phone3'); ?></li>
                            <li><?php echo ale_get_option('phone4'); ?></li>
                            <li><?php echo ale_get_option('email2'); ?></li>
                            <li><?php echo ale_get_option('address2'); ?></li>
                        </ul>
                    </div>

                </div>

            </div>
        </div>


        <div class="line-3 cf">

            <div class="center-align cf">

                <div class="col-6">
                    <ul class="social">

                        <?php if(ale_get_option('insta')){ ?> <li class="instagram"><a href="<?php echo ale_get_option('insta'); ?>" rel="external" title="Instagram"></a></li> <?php } ?>
                        <?php if(ale_get_option('flickr')){ ?> <li class="flickr"><a href="<?php echo ale_get_option('flickr'); ?>" rel="external" title="Flickr"></a></li> <?php } ?>
                        <?php if(ale_get_option('pint')){ ?> <li class="pinterest"><a href="<?php echo ale_get_option('pint'); ?>" rel="external" title="Pinterest"></a></li> <?php } ?>
                        <?php if(ale_get_option('twi')){ ?> <li class="twitter"><a href="<?php echo ale_get_option('twi'); ?>" rel="external" title="Twitter"></a></li> <?php } ?>
                        <?php if(ale_get_option('fb')){ ?> <li class="facebook"><a href="<?php echo ale_get_option('fb') ?>" rel="external" title="Facebook"></a></li> <?php } ?>
                    </ul>
                </div>

                <div class="col-6">
                    <?php if (ale_get_option('copyrights')) : ?>
                        <p><?php echo ale_option('copyrights'); ?></p>
                    <?php else: ?>
                        <p>&copy; <?php _e('2013 Blume. All Rights Reserved','aletheme'); ?></p>
                    <?php endif; ?>

                </div>

            </div>
        </div>

    </footer>

    <?php if(ale_get_option('skinselector') == "1") { ale_part('colorselector'); } ?>


    <?php //Close the Hide from home page
    if(is_page_template('page-home.php')) { ?>
        </div> <!-- /hide -->
    <?php } ?>

    <!-- Scripts -->
    <?php wp_footer(); ?>

</body>
</html>