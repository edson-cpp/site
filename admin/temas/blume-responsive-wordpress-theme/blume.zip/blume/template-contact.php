<?php 
/**
 * Template Name: Template Contact
 */
// send contact
if (isset($_POST['contact'])) {
	$error = ale_send_contact($_POST['contact']);
}
get_header(); ?>


    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <section class="contact-us contacts">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
            </div>

            <div class="text">
                <?php the_content(); ?>
            </div>
        </div>
    </section>

    <div class="contacts-map">
        <?php echo ale_get_meta('htmlmap'); ?>
        <a name="success"></a>
        <div class="get-in-touch">
            <div class="center-align">
                <div class="background">

                    <div class="get-in-caption"><span><?php _e('getting in touch is easy','aletheme'); ?></span></div>

                    <div class="center-align">
                            <form method="post" id="contact-form" action="<?php the_permalink();?>">
                                <?php if (isset($_GET['success'])) : ?>
                                    <p class="success"><?php _e('Thank you for your message!', 'aletheme')?></p>
                                <?php endif; ?>
                                <?php if (isset($error) && isset($error['msg'])) : ?>
                                    <p class="error"><?php echo $error['msg']?></p>
                                <?php endif; ?>
                            <div class="col-6">
                                <input name="contact[name]" type="text" value="<?php echo isset($_POST['contact']['name']) ? $_POST['contact']['name'] : ''?>" required="required" placeholder="<?php _e('Name','aletheme'); ?> *"/>
                                <input name="contact[email]" type="email" value="<?php echo isset($_POST['contact']['email']) ? $_POST['contact']['email'] : ''?>" required="required" placeholder="<?php _e('E-mail','aletheme'); ?> *"/>
                                <input name="contact[how]" type="text" value="<?php echo isset($_POST['contact']['how']) ? $_POST['contact']['how'] : ''?>" required="required" placeholder="<?php _e('Subject','aletheme'); ?> *"/>
                            </div>

                            <div class="col-6">
                                <textarea class="right" name="contact[message]" value="<?php echo isset($_POST['contact']['message']) ? $_POST['contact']['message'] : ''?>" required="required"  placeholder="<?php _e('Comment','aletheme'); ?> *"></textarea>
                                <input class="right" type="submit" value=""/>
                                <?php wp_nonce_field() ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endwhile; else: ?>
        <?php ale_part('notfound')?>
    <?php endif; ?>

<?php get_footer(); ?>