<?php
/**
 * The Template for displaying all single products.
 *
 * Override this template by copying it to yourtheme/woocommerce/single-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header('shop'); ?>
<section class="shop blog">
    <div class="center-align cf">
	<?php
		/**
		 * woocommerce_before_main_content hook
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action('woocommerce_before_main_content');
	?>

        <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
            <div class="caption">
                <div class="line large left"></div>
                <div class="line large right"></div>
                <span>[</span><span class="cap"><?php woocommerce_page_title(); ?></span><span>]</span>
            </div>
        <?php endif; ?>
        <div class="singlewoopage cf">
            <div class="text col-8 content">
                <?php while ( have_posts() ) : the_post(); ?>

                    <?php woocommerce_get_template_part( 'content', 'single-product' ); ?>

                <?php endwhile; // end of the loop. ?>
            </div>


            <div class="col-4 right-side">
                <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('aletheme-woo-commerce') ) : endif; ?>
            </div>
        </div>
        <?php
        /**
         * woocommerce_after_main_content hook
         *
         * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
         */
        do_action('woocommerce_after_main_content');
        ?>

    </div>
</section>
<?php get_footer('shop'); ?>