<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" <?php language_attributes(); ?> data-themeurl="<?php echo get_template_directory_uri(); ?>" <?php if(ale_get_option('firstcolor')){ echo 'data-firstcolor="'.ale_get_option('firstcolor').'"'; } ?> <?php if(ale_get_option('secondcolor')){ echo 'data-secondcolor="'.ale_get_option('secondcolor').'"'; } ?>> <!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<title><?php wp_title('|', true, 'right'); bloginfo('name'); ?></title>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); echo ' style="'; if(ale_get_meta('custombg')){echo 'background-image:url('.ale_get_meta('custombg').');';} if(ale_get_meta('custompagecss')){ echo ale_get_meta('custompagecss');}echo '"'; ?> >

    <?php //Site pre loader on Home page
        if(is_page_template('page-home.php')) { ?>
        <!-- While Loading -->
        <div id="page-loading">
            <div id="fountainTextG">
                <div id="fountainTextG_1" class="fountainTextG">C</div>
                <div id="fountainTextG_2" class="fountainTextG">R</div>
                <div id="fountainTextG_3" class="fountainTextG">E</div>
                <div id="fountainTextG_4" class="fountainTextG">A</div>
                <div id="fountainTextG_5" class="fountainTextG">T</div>
                <div id="fountainTextG_6" class="fountainTextG">I</div>
                <div id="fountainTextG_7" class="fountainTextG">V</div>
                <div id="fountainTextG_8" class="fountainTextG">E</div>
                <div id="fountainTextG_9" class="fountainTextG">&nbsp;</div>
                <div id="fountainTextG_10" class="fountainTextG">A</div>
                <div id="fountainTextG_11" class="fountainTextG">G</div>
                <div id="fountainTextG_12" class="fountainTextG">E</div>
                <div id="fountainTextG_13" class="fountainTextG">N</div>
                <div id="fountainTextG_14" class="fountainTextG">C</div>
                <div id="fountainTextG_15" class="fountainTextG">Y</div>
            </div>
        </div>
    <div id="page-hide">
    <?php } ?>



        <!-- Home Slider -->
        <div id="<?php if(is_page_template('page-home.php')) { echo "home-slider"; } else { echo "menu-wrap"; }?>" class="cf">
            <?php if(is_page_template('page-home.php')) {?>
            <ul class="slides">
                <?php $slider = ale_sliders_get_slider(ale_get_option('homeslugfull')); ?>
                <?php if($slider):?>
                    <?php foreach ($slider['slides'] as $slide) : ?>
                        <li style="background-image: url('<?php echo $slide['image'] ?>'); ">
                            <?php if($slide['title']){ ?><div class="caption"><?php echo $slide['title']; ?></div><?php } ?>
                            <?php if($slide['description']){ ?><div class="text"><?php echo $slide['description']; ?></div><?php } ?>
                            <?php if($slide['url']){ ?><div class="href"><a href="<?php echo $slide['url']; ?>"><?php _e('take a look','aletheme'); ?></a></div><?php } ?>
                            <div class="mask"></div>
                        </li>
                    <?php endforeach; ?>
                <?php endif;?>
            </ul>
            <?php } ?>

            <!-- Menu -->
            <nav id="main-menu">
                <div class="center-align">
                    <!-- Logo -->
                    <div class="logo">
                        <?php if(ale_get_option('sitelogo')){ ?>
                            <a href="<?php echo home_url(); ?>/" class="customlogo"><img src="<?php echo ale_get_option('sitelogo'); ?>" /></a>
                            <a href="<?php echo home_url(); ?>/" class="mobcustomlogo"><img src="<?php echo ale_get_option('mobsitelogo'); ?>" /></a>
                        <?php } else { ?>
                            <a href="<?php echo home_url(); ?>/" class="alelogo"><?php echo bloginfo('name'); ?></a>
                            <a href="<?php echo home_url(); ?>/" class="mobalelogo"><?php echo bloginfo('name'); ?></a>
                        <?php } ?>
                    </div>

                    <?php
                    if ( has_nav_menu( 'header_menu' ) ) {
                        wp_nav_menu(array(
                            'theme_location'=> 'header_menu',
                            'menu'			=> 'Header Menu',
                            'menu_class'	=> 'menu',
                            'walker'		=> new Aletheme_Nav_Walker(),
                            'container'		=> '',
                        ));
                    }
                    ?>

                    <!-- DropDown -->

                    <div class="menu-click-drop">
                        <a>MENU</a>

                        <?php
                        if ( has_nav_menu( 'mobile_menu' ) ) {
                            wp_nav_menu(array(
                                'theme_location'=> 'mobile_menu',
                                'menu'			=> 'Mobile Menu',
                                'menu_class'	=> 'dropdown-menu',
                                'walker'		=> new Aletheme_Nav_Walker(),
                                'container'		=> '',
                            ));
                        }
                        ?>
                    </div>
                </div>
            </nav>
        </div>
        <?php if(!is_page_template('page-home.php')) { ?>
        <div id="menu-wrap-bottom">
            <div class="center-align">
                <div class="is-page"><?php get_breadcrumbs(); ?></div>
            </div>
            <div class="balls"></div>
        </div>
        <?php } ?>