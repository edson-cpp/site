<?php get_header(); ?>
    <!-- Our Works -->
    <section class="our-works portfolio">
        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Our Works','aletheme'); ?></span><span>]</span>
            </div>

            <div class="menu">
                <a href="<?php echo home_url(); ?>/gallery" class="active"><?php _e('All', 'aletheme')?></a>
                <?php $args = array(
                    'type'                     => 'gallery',
                    'child_of'                 => 0,
                    'parent'                   => '',
                    'orderby'                  => 'name',
                    'order'                    => 'ASC',
                    'hide_empty'               => 1,
                    'hierarchical'             => 1,
                    'exclude'                  => '',
                    'include'                  => '',
                    'number'                   => '',
                    'taxonomy'                 => 'gallery-category',
                    'pad_counts'               => false );

                $categories = get_categories( $args );

                foreach($categories as $cat){
                    echo '<a href="'.home_url().'/gallery-category/'.$cat->slug.'">'.$cat->name.'</a>';
                }
                ?>
            </div>

            <div id="post" class="gallery cf">

                <?php $g_counter=0; if (have_posts()) : while (have_posts()) : the_post(); $g_counter++; ?>
                <div class="post <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") { echo "col-6"; } else {echo "col-3";} ?>">
                    <a href="<?php the_permalink(); ?>">
                        <div class="outlines">
                            <div class="triangle"><p>+</p></div>
                        </div>
                        <div class="mask"></div>
                        <span><?php echo the_title(); ?></span>

                        <?php if($g_counter=="1" or $g_counter=="6" or $g_counter=="7") {
                            echo get_the_post_thumbnail($post->ID,'gallery-big');
                        } else {
                            echo get_the_post_thumbnail($post->ID,'gallery-mini');
                        } ?>
                    </a>
                </div>
                <?php endwhile; else: ?>
                    <?php ale_part('notfound')?>
                <?php endif; ?>
            </div>

            <?php global $wp_query; if($wp_query->max_num_pages > 1){ ?>
            <div class="load" id="pbd-alp-load-posts"><a><?php _e('Load More','aletheme'); ?><span></span></a></div>
            <?php } ?>
        </div>
    </section>
<?php get_footer(); ?>