<?php get_header(); ?>

    <section class="blog">
    <div class="center-align">
        <div class="caption">
            <div class="line left"></div>
            <div class="line right"></div>
            <span>[</span><span class="cap"><?php _e('Our Blog','aletheme'); ?></span><span>]</span>
        </div>
    </div>

    <div class="center-align main">

        <?php if(ale_get_option('sidebarblog')=='2c-l-fixed'){
            ale_part('blog-left-sidebar');
        } ?>

        <!-- Content -->
        <div class="<?php if(ale_get_option('sidebarblog')=='2c-l-fixed' or ale_get_option('sidebarblog')=='2c-r-fixed'){ ?>col-8 content<?php } ?> content-opened" <?php if(ale_get_option('sidebarblog')=='2c-l-fixed'){ ?> style="padding-left:15px;" <?php } elseif(ale_get_option('sidebarblog')=='2c-r-fixed'){?> style="padding-right:15px;" <?php } ?>>
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <?php if(get_the_post_thumbnail()){ ?>
                <div class="img">
                    <?php echo get_the_post_thumbnail($post->ID,'full'); ?>
                    <div class="info"><?php _e('POSTED BY','aletheme');?> <?php echo get_the_author(); ?> <?php _e('ON','aletheme'); ?> <?php echo get_the_date(); ?> / <?php echo get_comments_number(); ?> <?php _e('COMMENTS','aletheme'); ?></div>
                </div>
            <?php } ?>
            <div class="caption"><?php the_title(); ?></div>

            <div class="text pagecontent story"><?php

                the_content();

                //Add view variable count
                ale_postviews( $post->ID, 'count' );

            ?>

            <?php if(get_the_tags()){ ?>
                <p class="tagsphar"><?php the_tags(); ?></p>
            <?php } ?>

            <?php wp_link_pages(array(
                'before' => '<p>' . __('Pages:', 'aletheme'),
                'after'	 => '</p>',
            )) ?>
            </div>



            <?php if (ale_get_option('social_sharing')) : ?>
                <div class="soc">
                    <ul>
                        <li class="pinterest"><a href="<?php echo ale_get_share('pin'); ?>" onclick="window.open(this.href, 'Share on Pinterest', 'width=600,height=300'); return false"></a></li>
                        <li class="twitter"><a href="<?php echo ale_get_share('twi'); ?>" onclick="window.open(this.href, 'Share on Twitter', 'width=600,height=300'); return false"></a></li>
                        <li class="facebook"><a href="<?php echo ale_get_share('fb'); ?>" onclick="window.open(this.href, 'Share on Facebook', 'width=600,height=300'); return false"></a></li>
                    </ul>
                </div>
            <?php endif; ?>

            <?php endwhile; else: ?>
                <?php ale_part('notfound')?>
            <?php endif; ?>

            <div class="related-posts">
                <span><?php _e('Related Posts','aletheme'); ?></span>
                <div>
                    <?php wp_reset_query(); query_posts('&post_type=post&ignore_sticky_posts=1&posts_per_page=3'); ?>
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <div class="col-4">
                        <?php echo get_the_post_thumbnail($post->ID,'post-mini'); ?>
                        <div class="caption"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </div>
                        <div class="date"><?php echo get_the_date(); ?></div>
                        <ul class="info">
                            <li class="views"><span></span>  <?php echo ale_postviews($post->ID, 'display'); ?></li>
                            <li class="comments"><span></span> <?php echo get_comments_number(); ?></li>
                        </ul>
                    </div>
                    <?php endwhile; else: ?>
                        <?php ale_part('notfound')?>
                    <?php endif; wp_reset_query(); ?>
                </div>
            </div>

            <?php comments_template(); ?>
        </div>

        <?php if(ale_get_option('sidebarblog')=='2c-r-fixed') {
            ale_part('blog-right-sidebar');
        } ?>
    </div>
    </section>

<?php get_footer(); ?>