<div class="col-4 right-side">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('right-sidebar') ) : endif; ?>
</div>