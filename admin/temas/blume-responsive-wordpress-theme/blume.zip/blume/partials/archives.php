<div id="archives" class="cf">
	<?php ale_archives(false); ?>
</div>