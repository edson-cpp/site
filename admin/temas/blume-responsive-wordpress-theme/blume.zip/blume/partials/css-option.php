<?php
$ale_background = ale_get_option('background');
$ale_headerfont = ale_get_option('headerfont');
$ale_mainfont = ale_get_option('mainfont');
$ale_font = ale_get_option('bodystyle');
$ale_h1 = ale_get_option('h1sty');
$ale_h2 = ale_get_option('h2sty');
$ale_h3 = ale_get_option('h3sty');
$ale_h4 = ale_get_option('h4sty');
$ale_h5 = ale_get_option('h5sty');
$ale_h6 = ale_get_option('h6sty');


/* Function to convert HEX colors to RGB */
function hex2rgb($hex) {
    $hex = str_replace("#", "", $hex);

    if(strlen($hex) == 3) {
        $r = hexdec(substr($hex,0,1).substr($hex,0,1));
        $g = hexdec(substr($hex,1,1).substr($hex,1,1));
        $b = hexdec(substr($hex,2,1).substr($hex,2,1));
    } else {
        $r = hexdec(substr($hex,0,2));
        $g = hexdec(substr($hex,2,2));
        $b = hexdec(substr($hex,4,2));
    }
    $rgb = array($r, $g, $b);
    //return implode(",", $rgb); // returns the rgb values separated by commas
    return $rgb; // returns an array with the rgb values
}
?>
<?php
    if(ale_get_option('headerfontex')){ $headerfontex = ":".ale_get_option('headerfontex'); }
    if(ale_get_option('mainfontex')){ $mainfontex = ":".ale_get_option('mainfontex'); }
    if(ale_get_option('headerfont')){ echo "<link href='http://fonts.googleapis.com/css?family=".ale_get_option('headerfont').$headerfontex."|".ale_get_option('mainfont').$mainfontex."' rel='stylesheet' type='text/css'>"; } else { echo "<link href=\"http://fonts.googleapis.com/css?family=Noto+Sans\" rel=\"stylesheet\" type=\"text/css\">"; }
?>
<style type='text/css'>
    body {
        <?php
        if($ale_font['size']){ echo "font-size:".$ale_font['size'].";"; };
        if($ale_font['style']){ echo "font-style:".$ale_font['style'].";"; };
        if($ale_font['color']){ echo "color:".$ale_font['color'].";"; };
        if($ale_font['face']){ $fontfamily =  str_replace ('+',' ',$ale_font['face']); echo "font-family:".$fontfamily.";"; };
        ?>
    }
    h1 {
        <?php
        if($ale_h1['size']){ echo "font-size:".$ale_h1['size'].";"; };
        if($ale_h1['style']){ echo "font-style:".$ale_h1['style'].";"; };
        if($ale_h1['color']){ echo "color:".$ale_h1['color'].";"; };
        if($ale_h1['face']){ $h1family =  str_replace ('+',' ',$ale_h1['face']); echo "font-family:".$h1family.";"; };
        ?>
    }
    h2 {
        <?php
        if($ale_h2['size']){ echo "font-size:".$ale_h2['size'].";"; };
        if($ale_h2['style']){ echo "font-style:".$ale_h2['style'].";"; };
        if($ale_h2['color']){ echo "color:".$ale_h2['color'].";"; };
        if($ale_h2['face']){ $h2family =  str_replace ('+',' ',$ale_h2['face']); echo "font-family:".$h2family.";"; };
        ?>
    }
    h3 {
        <?php
        if($ale_h3['size']){ echo "font-size:".$ale_h3['size'].";"; };
        if($ale_h3['style']){ echo "font-style:".$ale_h3['style'].";"; };
        if($ale_h3['color']){ echo "color:".$ale_h3['color'].";"; };
        if($ale_h3['face']){ $h3family =  str_replace ('+',' ',$ale_h3['face']); echo "font-family:".$h3family.";"; };
        ?>
    }
    h4 {
        <?php
        if($ale_h4['size']){ echo "font-size:".$ale_h4['size'].";"; };
        if($ale_h4['style']){ echo "font-style:".$ale_h4['style'].";"; };
        if($ale_h4['color']){ echo "color:".$ale_h4['color'].";"; };
        if($ale_h4['face']){ $h4family =  str_replace ('+',' ',$ale_h4['face']); echo "font-family:".$h4family.";"; };
        ?>
    }
    h5 {
        <?php
        if($ale_h5['size']){ echo "font-size:".$ale_h5['size'].";"; };
        if($ale_h5['style']){ echo "font-style:".$ale_h5['style'].";"; };
        if($ale_h5['color']){ echo "color:".$ale_h5['color'].";"; };
        if($ale_h5['face']){ $h5family =  str_replace ('+',' ',$ale_h5['face']); echo "font-family:".$h5family.";"; };
        ?>
    }
    h6 {
        <?php
        if($ale_h6['size']){ echo "font-size:".$ale_h6['size'].";"; };
        if($ale_h6['style']){ echo "font-style:".$ale_h6['style'].";"; };
        if($ale_h6['color']){ echo "color:".$ale_h6['color'].";"; };
        if($ale_h6['face']){ $h6family =  str_replace ('+',' ',$ale_h6['face']); echo "font-family:".$h6family.";"; };
        ?>
    }

    /*Main Font*/
    p, #menu-wrap-bottom .is-page, section.our-service .text a, section.our-service .icons .text p, .our-process .text p,
    .our-works .view a, section.portfolio3 .pagination a, section.portfolio .description .info, .shop .pagination a, .shop-opened .col-4 .tags li a,
    .blog .right-side .tags li a, .blog .content .pagination a, .blog .content2 .pagination a{
        <?php if($ale_headerfont){ $headerfontname =  str_replace ('+',' ',$ale_headerfont); echo "font-family:".$headerfontname.";"; } ?>
    }

    /*Header Font*/
    #page-loading .fountainTextG, #home-slider .slides li .caption,
    #home-slider .slides li .text, #home-slider .slides li .href a,
    #main-menu .center-align > ul li, #main-menu .center-align > ul li ul li,
    section .caption > span.cap, section.our-service .icons .caption, .why-choose-us .caption p,
    .why-choose-us #why-choose li a, .why-choose-us .news .items .item .caption, .why-choose-us .news .items .item span,
    .our-process .chart p, .our-process .caption, section.about-us .text span, section.about-us .peoples .col-3 span,
    .our-skills .prog-bars .bar span, .some-facts .content span, .our-works .menu a,
    .our-works .gallery .col-3 .outlines .triangle p, .our-works .gallery .col-3 span,
    .our-works .gallery .col-6 .outlines .triangle p, .our-works .gallery .col-6 span,
    .our-works .load a, section.portfolio2 .menu a, section.portfolio2 .gallery .col-2i5 a p,
    section.portfolio2 .load a, section.portfolio3 .head-line > span, section.portfolio3 .head-line .filter > a,
    section.portfolio3 .head-line .filter ul li, section.portfolio3 .gallery a p, section.portfolio3 .gallery .info .caption,
    section.portfolio3 .gallery .info .category, section.portfolio .head-line span, section.portfolio .description .caption,
    section.portfolio .description .info strong, section.portfolio .description .open, .rel-projects .projects .col-3 .info,
    .shop .head-line > span, .shop .head-line .filter > a, .shop .head-line .filter ul li, .shop .gallery a .sale,
    .shop .gallery .info .caption, .shop .gallery .info .price, .shop .gallery .info a, .shop-opened .col-8 .caption .name,
    .shop-opened .col-8 .caption .price .old, .shop-opened .col-8 .caption .price .new, .shop-opened .col-8 .filters .color .name,
    .shop-opened .col-8 .filters .color .filter > a, .shop-opened .col-8 .filters .color .filter ul li, .shop-opened .col-8 .filters .add-to > div,
    .shop-opened .col-8 .filters .add-to > div.minus a,
    .shop-opened .col-8 .filters .add-to > div.plus a, .shop-opened .col-8 .filters .add-to > a,
    .shop-opened .col-8 .gallery a .sale, .shop-opened .col-8 .gallery .info .caption, .shop-opened .col-8 .gallery .info .price,
    .shop-opened .col-8 .gallery .info a, .shop-opened .col-4 > span, .shop-opened .col-4 .categories li, .shop-opened .col-4 .filter > a,
    .shop-opened .col-4 #services li a, .blog .time-line .center-align .col-2i6 a, .blog .right-side > span,
    .blog .right-side .posts .items div .text, .blog .right-side .blog-testimonials .top p, .blog .right-side .blog-testimonials .bottom > a,
    .blog .right-side .categories li, .blog .content .post .img .info,
    .blog .content .post .video .info, .blog .content .post .gallery-img .info, .blog .content .post .caption a,
    .blog .content .post .href a, .blog .content2 .col-6 > a p,
    .blog .content2 .col-12 > a p, .blog .content2 .col-6 > a .date,
    .blog .content2 .col-12 > a .date, .blog .content2 .col-6 .caption,
    .blog .content2 .col-12 .caption, .blog .content2 .col-6 .date,
    .blog .content2 .col-12 .date, .blog .content2 .col-6 .href,
    .blog .content2 .col-12 .href, .blog .content2 .col-6 .info li,
    .blog .content2 .col-12 .info li, .blog .content-opened .img .info, .blog .content-opened .caption,
    .blog .content-opened .related-posts span, .blog .content-opened .related-posts .caption a, .blog .content-opened .related-posts .date,
    .blog .content-opened .related-posts .info li, .blog .content-opened > .comments span, .blog .content-opened > .comments .comment .comm .name,
    .blog .content-opened .reply span, .blog .content-opened .reply #reply-form input,
    .blog .content-opened .reply #reply-form textarea, div.testimonials .content span,
    section.testimonials-page .testimonials-list li .hover .name span, section.testimonials-page .load a,
    section.contact-us form input, section.contact-us form textarea, .contacts-map .get-in-touch .get-in-caption span,
    .contacts-map .get-in-touch form input, .contacts-map .get-in-touch form textarea, footer .line-1 span,
    footer .line-2 .nav li, footer .line-2 .map span, footer .line-2 .map ul li, footer .line-3 p, .menu-click-drop,
    .menu-click-drop ul.dropdown-menu li a,.widgettitle, .widget_pages ul,.widget_archive ul,.widget_categories ul,.widget_nav_menu ul,
    .widget_meta ul,.widget_recent_comments ul,.widget_recent_entries ul,.widget_search input,
    .ale-tabs .ale-nav li a,.ale-team .testititle,.ale-team .prof, .woocommerce a.button, .woocommerce button.button,.woocommerce input.button,.woocommerce #respond input#submit,.woocommerce #content input.button,
    .woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price,
    .woocommerce ul.products li.product .onsale, .woocommerce-page ul.products li.product .onsale,.woocommerce-result-count,
    .woocommerce-ordering select,.woocommerce .singlewoopage .onsale, .woocommerce-page .singlewoopage .onsale, input.qty,
    .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li,
    .woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li,
    .woocommerce table.cart th, .woocommerce-page table.cart th, .cart_totals tr strong,.cart_totals tr th,
    .woocommerce table.shop_table th, .woocommerce-page table.shop_table th,.woocommerce .widget_product_categories ul,
    .woocommerce-page .widget_product_categories ul,.woocommerce .widget_product_search input#s, .woocommerce-page .widget_product_search input#s,
    .woocommerce .widget_product_search input#searchsubmit, .woocommerce-page .widget_product_search input#searchsubmit,.headerfontcol,
    .lefttestimonialpart .testititle {
        <?php if($ale_mainfont){ $mainfontname =  str_replace ('+',' ',$ale_mainfont); echo "font-family:".$mainfontname.";"; } ?>
    }

    /* First Color */
    <?php if(ale_get_option('firstcolor')){?>

        /* Background Color */
        section.our-service .icons .ic1, section.our-service .icons .ic2, section.our-service .icons .ic3, section.our-service .icons .ic4,
        #home-slider .slides li .href a:hover,#main-menu .center-align > ul li ul li:hover,
        .our-skills .prog-bars .bar .progress,div.testimonials .col-4 .nav.left,div.testimonials .col-4 .nav.right,
        section.contact-us form input[type=submit],footer .line-2,
        section.blog .content2 .col-6 .href:hover, section.blog .content2 .col-12 .href:hover,
        section.blog .content2 .pagination span.current,section.blog .content2 .pagination a:hover,
        section.blog .content2 .pagination a.active,div.text.pagecontent .ale-service .iconbox,
        section.blog .content-opened .reply #reply-form input[type='submit'], section.blog .content-opened .reply #reply-form textarea[type='submit'],
        section.blog .content .post .href a:hover, section.blog .content .post .gallery-img .prev, section.blog .content .post .gallery-img .next,
        section.blog .content .post .gallery-img .next.disabled, section.blog .content .post .gallery-img .prev.disabled,
        section.blog .content .pagination span.current,section.blog .content .pagination a:hover, section.blog .content .pagination a.active,
        section.blog .right-side .aletheme-flickr .picture:nth-child(even),section.blog .right-side .widget_calendar #calendar_wrap table#wp-calendar caption,
        section.blog .right-side .widget_search input#searchsubmit, .our-works .load a:hover,section.portfolio .head-line ul .left,
        section.portfolio .head-line ul .right,section.portfolio .scrollable .prev,section.portfolio .scrollable .next,section.portfolio .scrollable .prev.disabled,section.portfolio .scrollable .next.disabled,
        section.portfolio .description .open:hover,section.portfolio3 .pagination span.current,section.portfolio3 .pagination a:hover, section.portfolio3 .pagination a.active,
        section.portfolio2 .menu a:hover, section.portfolio2 .menu a.active, .contacts-map .get-in-touch form input[type=submit],
        div.text.pagecontent .ale-toggle-title,div.text.pagecontent .ale-team .socialbut,div.text.pagecontent .flexslider .flex-next,
        div.text.pagecontent .flexslider .flex-prev,div.text.pagecontent .flexslider .flex-control-nav li a,
        .woocommerce span.onsale, .woocommerce-page span.onsale,.woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li span.current,
        .woocommerce nav.woocommerce-pagination ul li a.page-numbers:hover, .woocommerce-page nav.woocommerce-pagination ul li a.page-numbers:hover, .woocommerce #content nav.woocommerce-pagination ul li a.page-numbers:hover, .woocommerce-page #content nav.woocommerce-pagination ul li a.page-numbers:hover,
        .woocommerce a.button:hover, .woocommerce-page a.button:hover, .woocommerce button.button:hover, .woocommerce-page button.button:hover, .woocommerce input.button:hover, .woocommerce-page input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce-page #respond input#submit:hover,
        .woocommerce #content input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce .widget_product_search input#searchsubmit, .woocommerce-page .widget_product_search input#searchsubmit,
        .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, .woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li,
        .woocommerce table.cart a.remove:hover, .woocommerce-page table.cart a.remove:hover, .woocommerce #content table.cart a.remove:hover, .woocommerce-page #content table.cart a.remove:hover,
        .why-choose-us .caption p a.right,.why-choose-us .caption p a.left,.why-choose-us .caption p a:hover.disabled.left, .why-choose-us .caption p a:hover.disabled.right,
        section.testimonials-page .load a:hover {
            background-color: <?php echo ale_get_option('firstcolor'); ?>;
        }

        /* Color */
        section .caption span,section.our-service .text a,section.about-us .text span,section.about-us .peoples .col-3 span,
        .some-facts .content .chart span,.our-works .menu a:hover,.our-works .menu a.active,.our-works .view a,
        div.text.pagecontent a,#menu-wrap-bottom .is-page a,section.blog .content-opened .related-posts .caption a:hover,
        .rel-projects .projects .col-3 .info:hover, .woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price,
        .woocommerce ul.cart_list li a:hover, .woocommerce-page ul.cart_list li a:hover, .woocommerce ul.product_list_widget li a:hover, .woocommerce-page ul.product_list_widget li a:hover,
        .woocommerce div.product div.summary .pricebox p ins, .woocommerce-page div.product div.summary .pricebox p ins, .woocommerce #content div.product div.summary .pricebox p ins, .woocommerce-page #content div.product div.summary .pricebox p ins,
        .woocommerce table.cart a.remove, .woocommerce-page table.cart a.remove, .woocommerce #content table.cart a.remove, .woocommerce-page #content table.cart a.remove,
        .why-choose-us .caption p, .why-choose-us .news .items .item .caption:hover {
            color: <?php echo ale_get_option('firstcolor'); ?>;
        }

        /* Border Color */
        section.our-service .icons .icon,.our-works .menu a:hover,.our-works .menu a.active {
            border-color:<?php echo ale_get_option('firstcolor'); ?>;
        }

        /* RGBA Menu bg */
        <?php $mco = hex2rgb(ale_get_option('firstcolor')); ?>
        #main-menu,section.about-us .peoples .people:hover .mask {
           background: rgba(<?php echo $mco['0']; ?>,<?php echo $mco['1']; ?>,<?php echo $mco['2']; ?>,0.7);
        }
        .our-works .gallery .col-3 a:hover .mask {
            background: rgba(<?php echo $mco['0']; ?>,<?php echo $mco['1']; ?>,<?php echo $mco['2']; ?>,0.65);
        }
        section.blog .content2 .col-6 > a .mask, section.blog .content2 .col-12 > a .mask,section.portfolio3 .gallery a .mask,
        section.portfolio2 .gallery .col-2i5 a .mask {
            background: rgba(<?php echo $mco['0']; ?>,<?php echo $mco['1']; ?>,<?php echo $mco['2']; ?>,0.4);
        }
        section.portfolio .items div .mask {
            background: rgba(<?php echo $mco['0']; ?>,<?php echo $mco['1']; ?>,<?php echo $mco['2']; ?>,0.5);
        }
        section.testimonials-page .testimonials-list li:hover > .hover {
            background: rgba(<?php echo $mco['0']; ?>,<?php echo $mco['1']; ?>,<?php echo $mco['2']; ?>,0.6);
        }

        /* Custom */
        .our-works .gallery .col-6 .outlines .triangle {
            border-bottom-color:<?php echo ale_get_option('firstcolor'); ?>;
        }
    <?php } ?>

    /* Second Color */
    <?php if(ale_get_option('secondcolor')){?>

        /* Color */
        #home-slider .slides li .caption,#page-loading .fountainTextG {
            color: <?php echo ale_get_option('secondcolor'); ?>;
        }

        /* Background Color */
        #home-slider .slides li .href a,section.contact-us form input[type=submit]:hover,footer .line-1,
        section.blog .content2 .col-6 .href, section.blog .content2 .col-12 .href,
        section.blog .content2 .pagination a,div.text.pagecontent ul li:before,
        section.blog .right-side .widget_pages ul li.active, section.blog .right-side .widget_archive ul li.active,
        section.blog .right-side .widget_categories ul li.active, section.blog .right-side .widget_nav_menu ul li.active,
        section.blog .right-side .widget_meta ul li.active, section.blog .right-side .widget_recent_comments ul li.active,
        section.blog .right-side .widget_recent_entries ul li.active, section.blog .right-side .widget_pages ul li:hover,
        section.blog .right-side .widget_archive ul li:hover, section.blog .right-side .widget_categories ul li:hover,
        section.blog .right-side .widget_nav_menu ul li:hover, section.blog .right-side .widget_meta ul li:hover,
        section.blog .right-side .widget_recent_comments ul li:hover, section.blog .right-side .widget_recent_entries ul li:hover,
        section.blog .right-side .ale_mostcommented_widget .entry-thumb, section.blog .right-side .ale_blog_widget .entry-thumb,
        section.blog .content .post .href a,section.blog .content .post .gallery-img .next:hover,
        section.blog .content .post .gallery-img .prev:hover,section.blog .content .pagination a,
        section.blog .right-side .aletheme-flickr .picture:nth-child(odd),.our-works .load a,section.portfolio .head-line ul .left:hover,section.portfolio .head-line ul .right:hover,
        section.portfolio .scrollable .next:hover,section.portfolio .scrollable .prev:hover,section.portfolio .description .open,
        section.portfolio3 .head-line .filter > a, section.portfolio3 .head-line .filter ul li a:hover,section.portfolio3 .pagination a,section.portfolio2 .menu a,
        .contacts-map .get-in-touch form input[type=submit]:hover,div.text.pagecontent .flexslider .flex-next:hover,
        div.text.pagecontent .flexslider .flex-prev:hover,div.text.pagecontent .flexslider .flex-control-nav li a:hover,
        div.text.pagecontent .flexslider .flex-control-nav li a.flex-active,
        .woocommerce nav.woocommerce-pagination ul li a.page-numbers, .woocommerce-page nav.woocommerce-pagination ul li a.page-numbers, .woocommerce #content nav.woocommerce-pagination ul li a.page-numbers, .woocommerce-page #content nav.woocommerce-pagination ul li a.page-numbers,
        .woocommerce a.button, .woocommerce-page a.button, .woocommerce button.button, .woocommerce-page button.button, .woocommerce input.button, .woocommerce-page input.button, .woocommerce #respond input#submit, .woocommerce-page #respond input#submit, .woocommerce #content input.button, .woocommerce-page #content input.button,
        .woocommerce .widget_product_categories ul li.active, .woocommerce-page .widget_product_categories ul li.active, .woocommerce .widget_product_categories ul li:hover, .woocommerce-page .widget_product_categories ul li:hover,
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,
        .why-choose-us .caption p a:hover.right, .why-choose-us .caption p a:hover.left,
        section.testimonials-page .testimonials-list li .hover .name, section.testimonials-page .load a {
            background-color: <?php echo ale_get_option('secondcolor'); ?>;
        }

        /* Border Color*/
        #home-slider .flex-direction-nav a,#main-menu .center-align > ul li.current-menu-item,
        section.about-us .peoples .people,div.testimonials .people,blockquote,
        .ale-testimonial .lefttestimonialpart .avatarimage {
            border-color: <?php echo ale_get_option('secondcolor'); ?>;
        }

        /* Custom */
        #main-menu .center-align > ul li.current-menu-item:after,.our-works .gallery .col-3 .outlines .triangle {
            border-bottom-color: <?php echo ale_get_option('secondcolor'); ?>;
        }

        /* White images wen color is changed */
        #home-slider .flex-direction-nav a.flex-next {
            background: url("<?php echo get_template_directory_uri();?>/css/images/right-w.png") no-repeat center;
        }
        #home-slider .flex-direction-nav a.flex-prev {
            background: url("<?php echo get_template_directory_uri();?>/css/images/left-w.png") no-repeat center;
        }
        section.our-service .icons .ic1 {
            background-image: url('<?php echo get_template_directory_uri();?>/css/images/services/icon1-w.png');
        }
        section.our-service .icons .ic2 {
            background-image: url('<?php echo get_template_directory_uri();?>/css/images/services/icon2-w.png');
        }
        section.our-service .icons .ic3 {
            background-image: url('<?php echo get_template_directory_uri();?>/css/images/services/icon3-w.png');
        }
        section.our-service .icons .ic4 {
            background-image: url('<?php echo get_template_directory_uri();?>/css/images/services/icon4-w.png');
        }
        footer .line-3 .social li.facebook {
            background-position: -34px -2px;
        }
        footer .line-3 .social li.twitter {
            background-position: -424px -2px;
        }
        footer .line-3 .social li.pinterest {
            background-position: -321px -2px;
        }
        footer .line-3 .social li.flickr {
            background-position: -130px -2px;
        }
        footer .line-3 .social li.instagram {
            background-position: -225px -2px;
        }

        /* RGB BG */
        <?php $mco2 = hex2rgb(ale_get_option('secondcolor')); ?>
        .our-works .gallery .col-6 a:hover .mask {
            background: rgba(<?php echo $mco2['0']; ?>,<?php echo $mco2['1']; ?>,<?php echo $mco2['2']; ?>,0.65);
        }
        section.blog .content-opened .img .info,section.blog .content .post .gallery-img .info,section.blog .content .post .img .info,
        section.blog .content .post .video .info {
            background: rgba(<?php echo $mco2['0']; ?>,<?php echo $mco2['1']; ?>,<?php echo $mco2['2']; ?>,0.7);
        }
        section.portfolio3 .head-line .filter ul li {
            background: rgba(<?php echo $mco2['0']; ?>,<?php echo $mco2['1']; ?>,<?php echo $mco2['2']; ?>,0.9);
        }

        /* Preloader animation color */
        @-moz-keyframes bounce_fountainTextG{
            0%{-moz-transform:scale(1);color:<?php echo ale_get_option('secondcolor'); ?>;}
            100%{-moz-transform:scale(.5);color:#FFFFFF;}
        }
        @-webkit-keyframes bounce_fountainTextG{
            0%{-webkit-transform:scale(1);color:<?php echo ale_get_option('secondcolor'); ?>;}
            100%{-webkit-transform:scale(.5);color:#FFFFFF;}
        }
        @-ms-keyframes bounce_fountainTextG{
            0%{-ms-transform:scale(1);color:<?php echo ale_get_option('secondcolor'); ?>;}
            100%{-ms-transform:scale(.5);color:#FFFFFF;}
        }
        @-o-keyframes bounce_fountainTextG{
            0%{-o-transform:scale(1);color:<?php echo ale_get_option('secondcolor'); ?>;}
            100%{-o-transform:scale(.5);color:#FFFFFF;}
        }
        @keyframes bounce_fountainTextG{
            0%{transform:scale(1);color:<?php echo ale_get_option('secondcolor'); ?>;}
            100%{transform:scale(.5);color:#FFFFFF;}
        }
    <?php } ?>

    <?php if(ale_get_option('sitepattern')){ ?>
    #menu-wrap, #menu-wrap-bottom, .why-choose-us .background, .our-process .background, section.about-us, .our-skills.about,
    section.portfolio3 .gallery .info, .rel-projects .background, section.blog .time-line, section.blog .right-side .blog-testimonials .bottom,
    section.blog .content-opened .soc, section.blog .content-opened > .comments .comment .comm, section.contact-us .background,
    .contacts-map .get-in-touch .background,.woocommerce ul.products li.product,
    .woocommerce-page ul.products li.product  {
        background-image: url('<?php echo ale_get_option('sitepattern'); ?>');
    }
    <?php } ?>

    <?php if($_COOKIE["blumepat"]) { ?>
    #menu-wrap, #menu-wrap-bottom, .why-choose-us .background, .our-process .background, section.about-us, .our-skills.about,
    section.portfolio3 .gallery .info, .rel-projects .background, section.blog .time-line, section.blog .right-side .blog-testimonials .bottom,
    section.blog .content-opened .soc, section.blog .content-opened > .comments .comment .comm, section.contact-us .background,
    .contacts-map .get-in-touch .background,.woocommerce ul.products li.product,
    .woocommerce-page ul.products li.product  {
        background-image: url('<?php echo get_template_directory_uri(); ?>/css/images/<?php echo $_COOKIE["blumepat"] ?>');
    }
    <?php } ?>
</style>