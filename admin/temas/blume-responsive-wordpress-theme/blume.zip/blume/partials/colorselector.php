<div class="colorselector cf">
    <div class="openbut"></div>
    <div class="bowithoption">
        <div class="title headerfontcol"><?php _e('Choose the color scheme','aletheme'); ?></div>
        <div class="boxes cf">
            <div class="icbox icbox1" data-col="color1" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin1"></span></div>
            <div class="icbox icbox2" data-col="color2" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin2"></span></div>
            <div class="icbox icbox3" data-col="color3" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin3"></span></div>
            <div class="icbox icbox4" data-col="color4" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin4"></span></div>
            <div class="icbox icbox5" data-col="color5" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin5"></span></div>
            <div class="icbox icbox6" data-col="color6" data-link="<?php echo get_template_directory_uri(); ?>"><span class="ictrin6"></span></div>
        </div>
        <div class="title headerfontcol"><?php _e('Choose the pattern','aletheme'); ?></div>
        <div class="boxes cf">
            <div class="icboxpat icpat1" data-pat="background.jpg" data-link="<?php echo get_template_directory_uri(); ?>"></div>
            <div class="icboxpat icpat2" data-pat="background2.png" data-link="<?php echo get_template_directory_uri(); ?>"></div>
            <div class="icboxpat icpat3" data-pat="background3.png" data-link="<?php echo get_template_directory_uri(); ?>"></div>
            <div class="icboxpat icpat4" data-pat="background4.png" data-link="<?php echo get_template_directory_uri(); ?>"></div>
            <div class="icboxpat icpat5" data-pat="background5.png" data-link="<?php echo get_template_directory_uri(); ?>"></div>
            <div class="icboxpat icpat6" data-pat="background6.png" data-link="<?php echo get_template_directory_uri(); ?>"></div>
        </div>
        <div class="title headerfontcol redcol"><?php _e('Note:','aletheme'); ?></div>
        <div class="boxes cf">
            In Theme Options panel you can choose unlimited color schemes  and upload unlimited patterns
        </div>
    </div>
</div>