<?php get_header(); ?>
<section class="about-us about">
    <div class="center-align">
        <div class="caption">
            <span>[</span><span class="cap"><?php the_title(); ?></span><span>]</span>
        </div>

        <div class="text pagecontent story">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <?php ale_part('pagehead');?>
            <?php the_content(); ?>
            <?php ale_part('pagefooter');?>
            <?php endwhile; else: ?>
                <?php ale_part('notfound')?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php get_footer(); ?>