<?php get_header(); ?>

    <!-- Portfolio Opened -->
    <section class="portfolio">

        <div class="center-align">
            <div class="caption">
                <div class="line left"></div>
                <div class="line right"></div>
                <span>[</span><span class="cap"><?php _e('Portfolio','aletheme'); ?></span><span>]</span>
            </div>
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="head-line">
                <span><?php echo the_title(); ?></span>

                <ul>
                    <li class="right"><a class="next"></a></li>
                    <li class="center"><a href="<?php echo home_url(); ?>/gallery"></a></li>
                    <li class="left"><a class="prev"></a></li>
                </ul>

            </div>

            <div class="scrollable" id="scrollable">
                <a class="next browse right"></a>
                <a class="prev browse left"></a>

                <div class="items">
                    <?php
                    $args = array(
                        'post_type' => 'attachment',
                        'numberposts' => -1,
                        'post_status' => null,
                        'order'				=> 'ASC',
                        'orderby'			=> 'menu_order ID',
                        'meta_query'		=> array(
                            array(
                                'key'		=> '_ale_hide_from_gallery',
                                'value'		=> 0,
                                'type'		=> 'DECIMAL',
                            ),
                        ),
                        'post_parent' => $post->ID
                    );
                    $attachments = get_posts( $args );
                    if ( $attachments ) {
                        foreach ( $attachments as $attachment ) {
                            echo "
                            <div>
                                <span class=\"mask\"></span>
                                ".wp_get_attachment_image( $attachment->ID, 'gallery-thumba' )."
                            </div>";
                        }
                    }
                    ?>
                </div>
            </div>

            <div class="description">
                <div class="proj col-9">
                    <div class="caption"><?php _e('project description','aletheme'); ?></div>

                    <div class="text">
                        <?php the_content(); ?>
                    </div>
                </div>

                <div class="details col-3">
                    <div class="caption"><?php _e('project details','aletheme'); ?></div>

                    <div class="info">
                        <strong><?php _e('Client','aletheme'); ?> : </strong> <?php echo ale_get_meta('gclient'); ?>
                    </div>
                    <div class="info">
                        <strong><?php _e('Date','aletheme'); ?> : </strong> <?php echo ale_get_meta('gdate'); ?>
                    </div>
                    <div class="info">
                        <strong><?php _e('Tags','aletheme'); ?> : </strong> <?php echo ale_get_meta('gtags'); ?>
                    </div>
                    <?php if(ale_get_meta('glink')){ ?><a class="open" href="<?php echo ale_get_meta('glink'); ?>" rel="external"><?php _e('View Online','aletheme'); ?></a><?php } ?>

                </div>

            </div>
            <?php endwhile; else: ?>
                <?php ale_part('notfound')?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Related Projects -->
    <section class="rel-projects">
        <div class="background">

            <div class="center-align">
                <div class="caption">
                    <div class="line small left"></div>
                    <div class="line small right"></div>
                    <span>[</span><span class="cap"><?php _e('Related projects','aletheme'); ?></span><span>]</span>
                </div>


                <div class="projects">
                    <?php query_posts('&post_type=gallery&posts_per_page=4'); ?>
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <div class="col-3">
                            <a href="<?php the_permalink(); ?>">
                                <?php echo get_the_post_thumbnail($post->ID,'gallery-mini'); ?>
                            </a>
                            <a class="info" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </div>
                    <?php endwhile; else: ?>
                        <?php ale_part('notfound')?>
                    <?php endif; ?>

                </div>

            </div>

        </div>
    </section>

<?php get_footer(); ?>