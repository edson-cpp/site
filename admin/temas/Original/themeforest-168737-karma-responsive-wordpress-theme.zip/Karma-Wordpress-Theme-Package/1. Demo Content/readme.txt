
This is a Wordpress Plugin that will automatically install demo content on your Karma Wordpress Theme.

--------------------------------------------------
*** Recommended Instructions ***
--------------------------------------------------
Follow this link for easy-to-follow video instructions:
http://vimeopro.com/truethemes/karma-4/


------------------------------
Manual Instructions:
------------------------------
1. Install and activate the plugin just as you would any normal plugin
2. Click on 'Appearance > Karma Demo Content Generator'
3. Follow the onscreen instructions
4. Enjoy :)