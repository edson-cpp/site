//This script is only enqueued into WordPress admin page editor, if Karma 4.0 is activated from Site Option.
//this script hide "Custom Settings" post meta box.
    jQuery(document).ready(function(){
    	jQuery("#new-meta-boxes").css('display','none'); 	       	    	   		
    });