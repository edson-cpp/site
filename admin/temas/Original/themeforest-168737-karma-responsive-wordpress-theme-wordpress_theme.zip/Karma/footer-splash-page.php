<?php
truethemes_before_footer_top(); //action hook introduced in 4.0 for wp-activate.php, do not remove
?>
		</div><!-- END main -->   
	</div><!-- END wrapper -->
</div><!-- END tt-layout -->
<?php wp_footer(); ?>

<!--[if !IE]><!--><script>
if (/*@cc_on!@*/false) {
    document.documentElement.className+=' ie10';
}
</script><!--<![endif]-->
</body>
</html>