<?php
/*
* This file automatically generates 'general' processes such as clear widgets from sidebar, create and set menu locations..
* in preparation for other processes.. returns menu ids etc… for later use.
* this file should always be the first to run!
*/

	//#message - clearing default widgets
	echo '<li>Clearing default widgets from sidebar, and pre-setting widgets.</li>';
	$widgets = get_option('sidebars_widgets');
	$widgets['sidebar-1'] = array(); //this will clear the first sidebar.
	$widgets['sidebar-3'] = array('recent-posts-2','archives-2','categories-2'); //adding recent posts widget to blog sidebar
	update_option('sidebars_widgets',$widgets);
	
	
	//? how about auto setting theme widgets to sidebar?
	//this probably will work http://themeshaper.com/2009/07/06/wordpress-theme-sidebar-template/
		
?>