<?php
/*------------------------
Developer Note:

Last number used was: $page_post_meta104

start with $page_post_meta105 for any newly added pages.
------------------------*/



/*
* This file automatically generates pages..
*/

	//#message - generating pages
	echo '<li>Creating Pages</li>';
	ob_flush();
	
//Create Homepage
	//notice $page_data1 and $page_id1 variable names, to avoid crashing with later pages.	
	$page_data1 = array(
  		'post_title'    => 'Home',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_content' => '[callout1]Karma doesn\'t lock you down to a specific homepage layout. All homepage layouts are completely customizable. The built in shortcode manager and pre-built shortcode layouts make it amazingly easy to create gorgeous layouts.[/callout1]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth_last]

[hr]

[one_half]
<h5>Latest from the Blog</h5>
[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="115" layout="default"]
[/one_half]

[one_half_last]
<h5>Awesome Content Here</h5>
Sed posuere consectetur est at lobortis. Sed posuere consectetur est at lobortis. Donec id elit non mi porta gravida at eget metus. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.

[/one_half_last]

[heading_horizontal type="h6" margin_top="20px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]
[testimonial]This is a testimonial Slider. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe, Truethemes[/client_name][/testimonial]
[testimonial]This testimonial is created using shortcode. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe,Themeforest[/client_name][/testimonial]
[testimonial]You can add any amount of slide here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe, Truethemes[/client_name][/testimonial]
[/testimonial_wrap]',
		
	);

	$page_post_meta1 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',	
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	
					//Slider settings
					'karma_slider_type'=>'karma-custom-jquery-2',
					'tt_karma_slider_category'=> $jquery_two_category_term_id, //found in generate_slider_posts.php
	);

	$preset_menu_item_id['home'] = tt_create_pages($page_data1,$page_post_meta1);
	
	
	
	//Set static page - WordPress admin > Settings > Reading ->  a static page
	update_option('show_on_front','page');
	//Set front page -  WordPress admin > Settings > Reading
	update_option('page_on_front',$preset_menu_item_id['home']);


	
	
//create blog page
	$page_data2 = array(
  		'post_title'    => 'Blog',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta2 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'default',	
						

	);
	$preset_menu_item_id['blog'] = tt_create_pages($page_data2,$page_post_meta2);
	//set blog posts - WordPress admin > Settings >  Reading
	update_option('page_for_posts',$preset_menu_item_id['blog']);
	
		


//jQuery 1 slider
	//notice $page_data3 and $page_id3 variable names, to avoid crashing with later pages.	
	$page_data3 = array(
  		'post_title'    => 'Karma jQuery 1 Slider',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_parent' => $preset_menu_parent_item_id['sliders'],
		'post_content' => '[callout1]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Curabitur blandit tempus porttitor. Praesent commodo cursus magna.[/callout1]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Compatible</h4>
<a href="http://codecanyon.net/item/ubermenu-wordpress-mega-menu-plugin/154703?ref=TrueThemes" target="_blank">UberMenu</a>, <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>, and <a href="http://wordpress.org/plugins/mailchimp/" target="_blank">MailChimp</a> Plugins are just some of the premium plugins that work seamlessly with Karma.
[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Dependable</h4>
Karma is built on highly optimized code that\'s already powering more than 20,000 websites. You can depend on this theme.
[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Personalized</h4>
Personalize your website by choosing from 30 preset color schemes, 7 gorgeous overlay patterns and so much more.
[/one_third_last]

[heading_horizontal type="h5" margin_top="35px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]

[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I’ve never turned a website around so fast! I’ll be looking for more themes from TrueThemes in the future. Thanks![client_name]TrueThemes Customer[/client_name][/testimonial]

[testimonial]I have purchased the Karma Theme and can completely recommend it. The training videos are wonderful, very clear and concise with detailed instructions and demonstration. The Technical Support has also been wonderful, the response time on a issue I had was phenomenal, plus the solution to my issue was provided in a very clear manner. I will be using Karma on my next project as well.[client_name]Janet[/client_name][/testimonial]

[testimonial]We are so AMAZED by the exceptional skills and professionalism that TrueThemes has showed our law firm. Their excellent support, fast ticket response and vision into design is top notch! We love this Karma theme and we’re so happy with the incredible assistance we’ve received from TrueThemes! Keep up the great work guys!! And Thank you![client_name]TrueThemes Customer[/client_name][/testimonial]

[/testimonial_wrap]',
		
	);

	$page_post_meta3 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',	
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	
					//Slider settings
					'karma_slider_type'=>'karma-custom-jquery-1',
					'tt_karma_slider_category'=> $jquery_one_category_term_id, //found in generate_slider_posts.php
	);

	$preset_menu_item_id['jquery-1-slider'] = tt_create_pages($page_data3,$page_post_meta3);	
	







//jQuery 2 slider
	//notice $page_data4 and $page_id4 variable names, to avoid crashing with later pages.	
	$page_data4 = array(
  		'post_title'    => 'Karma jQuery 2 Slider',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_parent' => $preset_menu_parent_item_id['sliders'],
		'post_content' => '[callout1]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Curabitur blandit tempus porttitor. Praesent commodo cursus magna.[/callout1]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth]

[one_fourth_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="#" target="" description="" size="four_col_large"]
Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
[/one_fourth_last]

&nbsp;

[hr]

[one_half]
<h5>Latest from the Blog</h5>
[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="115" layout="default"]
[/one_half]

[one_half_last]
<h5>Awesome Content Here</h5>
Sed posuere consectetur est at lobortis. Sed posuere consectetur est at lobortis. Donec id elit non mi porta gravida at eget metus. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.

[/one_half_last]

[heading_horizontal type="h6" margin_top="20px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]
[testimonial]This is a testimonial Slider. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe, Truethemes[/client_name][/testimonial]
[testimonial]This testimonial is created using shortcode. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe,Themeforest[/client_name][/testimonial]
[testimonial]You can add any amount of slide here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus rhoncus, arcu non blandit tempus, elit diam congue velit, ac porttitor enim purus sed ante. In feugiat, velit eleifend placerat scelerisque, tortor felis hendrerit neque, sit amet semper turpis velit fringilla risus. Mauris tempus risus non tortor mollis si[client_name]John Doe, Truethemes[/client_name][/testimonial]
[/testimonial_wrap]',
		
	);

	$page_post_meta4 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',	
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	
					//Slider settings
					'karma_slider_type'=>'karma-custom-jquery-2',
					'tt_karma_slider_category'=> $jquery_two_category_term_id, //found in generate_slider_posts.php
	);

	$preset_menu_item_id['jquery-2-slider'] = tt_create_pages($page_data4,$page_post_meta4);
	
	
	
	
	
//jQuery 3 slider
	//notice $page_data(x) and $page_id(x) variable names, to avoid crashing with later pages.	
	$page_data99 = array(
  		'post_title'    => 'Karma jQuery 3 Slider',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_parent' => $preset_menu_parent_item_id['sliders'],
		'post_content' => '[callout1]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Curabitur blandit tempus porttitor. Praesent commodo cursus magna.[/callout1]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Compatible</h4>
<a href="http://codecanyon.net/item/ubermenu-wordpress-mega-menu-plugin/154703?ref=TrueThemes" target="_blank">UberMenu</a>, <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>, and <a href="http://wordpress.org/plugins/mailchimp/" target="_blank">MailChimp</a> Plugins are just some of the premium plugins that work seamlessly with Karma.
[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Dependable</h4>
Karma is built on highly optimized code that\'s already powering more than 20,000 websites. You can depend on this theme.
[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Personalized</h4>
Personalize your website by choosing from 30 preset color schemes, 7 gorgeous overlay patterns and so much more.
[/one_third_last]

[heading_horizontal type="h5" margin_top="35px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]

[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I’ve never turned a website around so fast! I’ll be looking for more themes from TrueThemes in the future. Thanks![client_name]TrueThemes Customer[/client_name][/testimonial]

[testimonial]I have purchased the Karma Theme and can completely recommend it. The training videos are wonderful, very clear and concise with detailed instructions and demonstration. The Technical Support has also been wonderful, the response time on a issue I had was phenomenal, plus the solution to my issue was provided in a very clear manner. I will be using Karma on my next project as well.[client_name]Janet[/client_name][/testimonial]

[testimonial]We are so AMAZED by the exceptional skills and professionalism that TrueThemes has showed our law firm. Their excellent support, fast ticket response and vision into design is top notch! We love this Karma theme and we’re so happy with the incredible assistance we’ve received from TrueThemes! Keep up the great work guys!! And Thank you![client_name]TrueThemes Customer[/client_name][/testimonial]

[/testimonial_wrap]',
		
	);

	$page_post_meta99 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',	
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	
					//Slider settings
					'karma_slider_type'=>'karma-custom-jquery-3',
					'tt_karma_slider_category'=> $jquery_two_category_term_id, //found in generate_slider_posts.php
	);

	$preset_menu_item_id['jquery-3-slider'] = tt_create_pages($page_data99,$page_post_meta99);
	
	
	
	
	
	
	
	
//LayerSlider
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data100 = array(
  		'post_title'    => 'LayerSlider',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '<h1 style="text-align: center;">LayerSlider:</h1>
[callout1]Please check out the <a href="http://vimeopro.com/truethemes/karma-4/">Karma Training Videos</a> for complete details on setting up this page. Cheers :)[/callout1]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Compatible</h4>
<a href="http://codecanyon.net/item/ubermenu-wordpress-mega-menu-plugin/154703?ref=TrueThemes" target="_blank">UberMenu</a>, <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>, and <a href="http://wordpress.org/plugins/mailchimp/" target="_blank">MailChimp</a> Plugins are just some of the premium plugins that work seamlessly with Karma.
[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Dependable</h4>
Karma is built on highly optimized code that\'s already powering more than 20,000 websites. You can depend on this theme.
[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Personalized</h4>
Personalize your website by choosing from 30 preset color schemes, 7 gorgeous overlay patterns and so much more.
[/one_third_last]

[heading_horizontal type="h5" margin_top="35px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]

[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I’ve never turned a website around so fast! I’ll be looking for more themes from TrueThemes in the future. Thanks![client_name]TrueThemes Customer[/client_name][/testimonial]

[testimonial]I have purchased the Karma Theme and can completely recommend it. The training videos are wonderful, very clear and concise with detailed instructions and demonstration. The Technical Support has also been wonderful, the response time on a issue I had was phenomenal, plus the solution to my issue was provided in a very clear manner. I will be using Karma on my next project as well.[client_name]Janet[/client_name][/testimonial]

[testimonial]We are so AMAZED by the exceptional skills and professionalism that TrueThemes has showed our law firm. Their excellent support, fast ticket response and vision into design is top notch! We love this Karma theme and we’re so happy with the incredible assistance we’ve received from TrueThemes! Keep up the great work guys!! And Thank you![client_name]TrueThemes Customer[/client_name][/testimonial]

[/testimonial_wrap]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta100 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',
					
					//Page settings
    				'slider_disable_toolbar'=>'true',

	);

	$preset_menu_item_id['layer-slider'] = tt_create_pages($page_data100,$page_post_meta100);	
	
	








//LayerSlider
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data101 = array(
  		'post_title'    => 'Revolution Slider',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '<h1 style="text-align: center;">Revolution Slider:</h1>
[callout1]Please check out the <a href="http://vimeopro.com/truethemes/karma-4/">Karma Training Videos</a> for complete details on setting up this page. Cheers :)[/callout1]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Compatible</h4>
<a href="http://codecanyon.net/item/ubermenu-wordpress-mega-menu-plugin/154703?ref=TrueThemes" target="_blank">UberMenu</a>, <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>, and <a href="http://wordpress.org/plugins/mailchimp/" target="_blank">MailChimp</a> Plugins are just some of the premium plugins that work seamlessly with Karma.
[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Dependable</h4>
Karma is built on highly optimized code that\'s already powering more than 20,000 websites. You can depend on this theme.
[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="_self" description="" size="three_col_large"]
<h4>Personalized</h4>
Personalize your website by choosing from 30 preset color schemes, 7 gorgeous overlay patterns and so much more.
[/one_third_last]

[heading_horizontal type="h5" margin_top="35px" margin_bottom="35px"]Our Clients Say it Best[/heading_horizontal]

[testimonial_wrap]

[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I’ve never turned a website around so fast! I’ll be looking for more themes from TrueThemes in the future. Thanks![client_name]TrueThemes Customer[/client_name][/testimonial]

[testimonial]I have purchased the Karma Theme and can completely recommend it. The training videos are wonderful, very clear and concise with detailed instructions and demonstration. The Technical Support has also been wonderful, the response time on a issue I had was phenomenal, plus the solution to my issue was provided in a very clear manner. I will be using Karma on my next project as well.[client_name]Janet[/client_name][/testimonial]

[testimonial]We are so AMAZED by the exceptional skills and professionalism that TrueThemes has showed our law firm. Their excellent support, fast ticket response and vision into design is top notch! We love this Karma theme and we’re so happy with the incredible assistance we’ve received from TrueThemes! Keep up the great work guys!! And Thank you![client_name]TrueThemes Customer[/client_name][/testimonial]

[/testimonial_wrap]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta101 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-blank-canvas.php',
					
					//Page settings
    				'slider_disable_toolbar'=>'true',

	);

	$preset_menu_item_id['revolution-slider'] = tt_create_pages($page_data101,$page_post_meta101);
	




	



//portfolio one column using filterable gallery template and tags as submenu item to portfolio + gallery custom menu link
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data8 = array(
  		'post_title'    => '1 Column',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta8 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-1-col',
					'meta_truethemes_gallery_framestyle'=>'modern',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['1-column'] = tt_create_pages($page_data8,$page_post_meta8);




//portfolio one column portrait 	
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data9 = array(
  		'post_title'    => '1 Column Portrait',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta9 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-1-col-portrait',
					'meta_truethemes_gallery_framestyle'=>'modern',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['1-column-portrait'] = tt_create_pages($page_data9,$page_post_meta9);



//portfolio 2 column
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data10 = array(
  		'post_title'    => '2 Column',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta10 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-2-col',
					'meta_truethemes_gallery_framestyle'=>'shadow',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['2-column'] = tt_create_pages($page_data10,$page_post_meta10);
	
	
	
	
//portfolio 3 column
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data11 = array(
  		'post_title'    => '3 Column',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta11 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-3-col',
					'meta_truethemes_gallery_framestyle'=>'shadow',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['3-column'] = tt_create_pages($page_data11,$page_post_meta11);
	
	
	
		
//portfolio 3 column portrait
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data12 = array(
  		'post_title'    => '3 Column Portrait',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta12 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-3-col-portrait',
					'meta_truethemes_gallery_framestyle'=>'shadow',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['3-column-portrait'] = tt_create_pages($page_data12,$page_post_meta12);	
	
	
	
//portfolio 4 column
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data13 = array(
  		'post_title'    => '4 Column',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		
	);

	$page_post_meta13 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-filterable-gallery.php',	
						
					'meta_truethemes_gallery_layout'=>'tt-4-col',
					'meta_truethemes_gallery_framestyle'=>'modern',	
					'meta_truethemes_gallery_title_check'=>'yes',
					'meta_truethemes_gallery_description_check'=>'yes',
						
						//gparent_term_id from generate_gallery_posts.php, the metabox script accepts this value as an array, 
						//therefore need to convert before saving into meta_truethemes_gallery_category
					'meta_truethemes_gallery_category'=>$gparent_term_id,	
					'meta_truethemes_gallery_filter_linktext'=>'All',
					'meta_truethemes_gallery_itemcount'=>'',
	);

	$preset_menu_item_id['4-column'] = tt_create_pages($page_data13,$page_post_meta13);	
	
	
	
//contact Smart Phone
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data14 = array(
  		'post_title'    => 'Smartphone',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '<h3 dir="ltr">We want to hear from you.</h3>
<p dir="ltr">Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam quis risus eget urna mollis ornare vel eu leo. Donec id elit non mi porta gravida at eget metus. Vestibulum id ligula porta felis euismod semper. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</p>
[raw][contact-form subject="Subject Line to Email Here" to="sean@truethemes.net"]
[contact-field label="Name" type="name" required="true" /]
[contact-field label="Email" type="email" required="true" /]
[contact-field label="Website" type="url" /]
[contact-field label="Comment" type="textarea" required="true" /]
[/contact-form][/raw]

&nbsp;',
		'post_type' => 'page',
		
	);

	$page_post_meta14 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_contact_iphone.php',	
						

	);

	$preset_menu_item_id['smart-phone'] = tt_create_pages($page_data14,$page_post_meta14);
	
	
	
	

//contact google map
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data15 = array(
  		'post_title'    => 'Google Map',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[one_third]

[tt_vector_box icon="fa-calendar" size="fa-4x" color="#7D60A9" link_to_page="" target="" description=""]
<h3>Event Calendar</h3>
Use Karma\'s vector icon box shortcodes to link users to important areas on your website.

[/tt_vector_box]
[/one_third]

[one_third]

[tt_vector_box icon="fa-clock-o " size="fa-4x" color="#87C442" link_to_page="" target="" description=""]
<h3>Meeting Times</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]

[/one_third]

[one_third_last]

[tt_vector_box icon="fa-rss" size="fa-4x" color="#FF8300" link_to_page="" target="" description=""]
<h3>RSS Feed</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]

&nbsp;

[/one_third_last]
[heading_horizontal type="h5" margin_top="30px" margin_bottom="30px"]Contact Form[/heading_horizontal]

[callout2]The contact form below was created in less than 2 minutes using Karma\'s powerful Form Builder. Contact forms can be inserted into any area of your website including pages, posts, footer and sidebar regions. This form below is for demo purposes only and will mail out to our auto-response system.[/callout2]

[two_thirds]

[raw][contact-form subject="Subject Line to Email Here" to="hello@truethemes.net"]
[contact-field label="Name" type="name" required="true" /]
[contact-field label="Email" type="email" required="true" /]
[contact-field label="Website" type="url" /]
[contact-field label="Comment" type="textarea" required="true" /]
[/contact-form][/raw]

[/two_thirds]

[one_third_last]
<h3>Lets Socialize:</h3>
[social style="vector_color" show_title="false" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]
<h3>Talk to us:</h3>
[business_contact
phone_number="123-456-7890"
skype_username="your-username-here" skype_label="Skype" email_address="hello@truethemes.net" directions_url="http://goo.gl/maps/996Zi" directions_label="get driving directions"]

[/one_third_last]',
		'post_type' => 'page',
		
	);

	$page_post_meta15 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_contact_googlemap.php',	
						

	);

	$preset_menu_item_id['google-map'] = tt_create_pages($page_data15,$page_post_meta15);		
	
			

//utility sitemap
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data16 = array(
  		'post_title'    => 'Site Map',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '',
  		'post_type' => 'page',
		
	);

	$page_post_meta16 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_sitemap.php',	
						

	);

	$preset_menu_item_id['sitemap'] = tt_create_pages($page_data16,$page_post_meta16);
	
	
	
	
	
//utility sitemap2
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data17 = array(
  		'post_title'    => 'Site Map 2',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '',
  		'post_type' => 'page',
		
	);

	$page_post_meta17 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_sitemap-2.php',	
						

	);

	$preset_menu_item_id['sitemap-2'] = tt_create_pages($page_data17,$page_post_meta17);

	
	

//team members
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data18 = array(
  		'post_title'    => 'Team Members',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[team_member style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" members_name="John Doe" members_title="CEO and Producer" link_to_page="" description="" last_item=""]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo. Donec ullamcorper nulla non metus auctor fringilla. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Cras justo odio, dapibus ac facilisis in, egestas eget quam.

[social style="vector" show_title="true" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" foursquare="" delicious="" digg="" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[/team_member]

[team_member style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" members_name="Jane Doe" members_title="Head of Marketing" link_to_page="" description="" last_item=""]

<strong>This example shows the shadow image frame and colored social icons. Setting both is an absolute breeze.</strong>

Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo. Donec ullamcorper nulla non metus auctor fringilla. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.

[social style="vector_color" show_title="true" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" foursquare="" delicious="" digg="" google="#" dribbble="#" skype="" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[/team_member]

[team_member style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" members_name="Chuck Norris" members_title="Head of Security" link_to_page="" description="" last_item="true"]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo. Donec ullamcorper nulla non metus auctor fringilla. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Cras justo odio, dapibus ac facilisis in, egestas eget quam.

[social style="vector" show_title="true" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" foursquare="" delicious="" digg="" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[/team_member]

[heading_horizontal type="h6" margin_top="40px" margin_bottom="40px"]Lets get started...[/heading_horizontal]

[one_third]

[button size="medium" style="royalblue" url="#" target="" icon="icon-cloud-download" popup="" title=""]Download Media Kit[/button]

[/one_third]

[one_third]

[button size="medium" style="skyblue" url="#" target="" icon="icon-skype" popup="" title=""]Call us on Skype[/button]

[/one_third]

[one_third_last]

[button size="medium" style="buoyred" url="#" target="" icon="icon-calendar-empty" popup="" title=""]View our Calendar[/button]

[/one_third_last]',
  		'post_type' => 'page',
		
	);

	$page_post_meta18 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox' => 'on',	
						

	);

	$preset_menu_item_id['team-members'] = tt_create_pages($page_data18,$page_post_meta18);
	
	
	
	
	
	

//team members - 2
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data104 = array(
  		'post_title'    => 'Team Members - 2',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[video_left][video_frame]
[iframe url="http://player.vimeo.com/video/35565030" width="572" height="312"]
[/video_frame]

[video_text]
[h2]Our Philosophy[/h2]
Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Maecenas sed diam eget risus varius blandit sit amet non magna. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Maecenas sed diam eget risus varius blandit sit amet non magna.
[/video_text][/video_left]

[heading_horizontal type="h6" margin_top="30px" margin_bottom="30px"]Meet The Team[/heading_horizontal]

[one_third][frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">John Doe</h4>
<p class="team-member-title">CEO and Producer</p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]

[/one_third]

[one_third]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">Jane Doe</h4>
<p class="team-member-title">Head of Marketing</p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]
[/one_third]

[one_third_last]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">Chuck Norris</h4>
<p class="team-member-title">Head of Security</p>
Chuck Norris and Superman once fought each other on a bet. The loser had to start wearing his underwear on the outside of his pants. Warning! Never look Chuck in the eyes.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]
[/one_third_last]

[hr]

[one_third]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">John Doe</h4>
<p class="team-member-title">CEO and Producer</p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]

[/one_third]

[one_third]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">Child Prodigy</h4>
<p class="team-member-title">Head of Marketing</p>
It took him 10 minutes and 23 seconds to master all of Mozart\'s musical works. He Solved his first Rubik\'s Cube at 2 months old, with 4 moves in 14 seconds.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]

[/one_third]

[one_third_last]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="square"]
<h4 class="team-member-name">Chuck Norris</h4>
<p class="team-member-title">Head of Security</p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Nullam quis risus eget urna mollis ornare vel eu leo.

[social style="vector_color" show_title="false" rss="" twitter="#" facebook="#" email="#" flickr="" youtube="" linkedin="#" pinterest="" instagram="#" foursquare="" delicious="" digg="" google="#" dribbble="" skype="" rss_title="RSS" twitter_title="" facebook_title="" email_title="" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="" pinterest_title="Pinterest" instagram_title="" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="" dribbble_title="Dribbble" skype_title=""]
[/one_third_last]

&nbsp;

[hr]

[testimonial_wrap]

[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I’ve never turned a website around so fast! I’ll be looking for more themes from TrueThemes in the future. Thanks![client_name]TrueThemes Customer[/client_name][/testimonial]

[testimonial]I have purchased the Karma Theme and can completely recommend it. The training videos are wonderful, very clear and concise with detailed instructions and demonstration. The Technical Support has also been wonderful, the response time on a issue I had was phenomenal, plus the solution to my issue was provided in a very clear manner. I will be using Karma on my next project as well.[client_name]Janet[/client_name][/testimonial]

[testimonial]We are so AMAZED by the exceptional skills and professionalism that TrueThemes has showed our law firm. Their excellent support, fast ticket response and vision into design is top notch! We love this Karma theme and we’re so happy with the incredible assistance we’ve received from TrueThemes! Keep up the great work guys!! And Thank you![client_name]TrueThemes Customer[/client_name][/testimonial]

[/testimonial_wrap]',
  		'post_type' => 'page',
		
	);

	$page_post_meta104 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox' => 'on',	
						

	);

	$preset_menu_item_id['team-members-2'] = tt_create_pages($page_data104,$page_post_meta104);

	





//FAQ -1 
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data19 = array(
  		'post_title'    => 'FAQ - 1',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[one_third]

[tt_vector_box icon="fa-gear" size="fa-4x" color="#2EC6C8" link_to_page="" target="" description=""]
<h3>General</h3>
Karma Wordpress Theme

[/tt_vector_box]
[/one_third]

[two_thirds_last]

[accordion class=\'accord1\']
[slide name="Can I really use a slider on any page layout?"]Yes. Karma now offers the ability to insert a slider on every page template. When creating a page you\'ll simply use Karma\'s custom \'Slider Settings\' section of the Page Editing screen to customize and insert your Slider. We\'ve made sure to stay true to the default Wordpress interface so absolutely nothing new to learn. Gone are the days of being locked down to a "homepage template". Boo-yah! [/slide]

[slide name="Is it true I can have unlimited Gallery Pages?"]Indeed it is. In Karma 4.0 we have made it possible to create unlimited Gallery Pages using Parent and Child Categories. First you will go to Gallery Posts &gt; Categories in the Wordpress backend, then create a Category, by default it will be a Parent. Now any category you create after just select that previous category as a parent. Each Parent Category represents its own gallery. So now all you have to do is choose the parent category in the page editor for the page you wish to display the gallery on. [/slide]

[slide name="Can I use Shortcodes in a Blog Post?"]Yes you can. We have taken the liberty of putting together some recommended shortcodes for the blog. For recommended Columns <a title="Recommended Columns for Blog" href="http://themes.truethemes.net/Karma-4.0/shortcodes-in-the-blog/" target="_blank">Click Here</a>. And for other Shortcode examples <a title="Shortcodes in the Blog" href="http://themes.truethemes.net/Karma-4.0/shortcodes-in-the-blog-pt-2/" target="_blank">Click Here.</a>[/slide]

[slide name="How is it I can build my own homepage?"]We won\'t get into all the technical jargen. We will however say it is as easy as riding a bike. In Karma 4.0 there is no set homepage layout. We have given you the option to use any of the layout templates (Left Sidebar, Right Nav + Sidebar, ect.) as your homepage layout. Also in the Page Editor we have allowed you to turn off certain elements such as the Title Bar to better suit your homepage needs. Combine that with being able to put a slider on any page and VOILA, you get to make your own homepage. Once again, Have Fun! [/slide]

[slide name="Can I use Google Fonts with Karma 4.0?"]You bet you can. Just travel on over to the custom Site Options Panel (Appearance &gt; Site Options &gt; Fonts). When there you will have the ability to choose from 11 preset samples we have provided for the Google Fonts. Or you have the option to enter your own custom font. Cheers![/slide]
[/accordion]

[/two_thirds_last]

[gap size="20px"]

[one_third]

[tt_vector_box icon="fa-desktop" size="fa-4x" color="#34BBEA" link_to_page="" target="" description=""]
<h3>Design</h3>
Beautifully crafted

[/tt_vector_box]
[/one_third]

[two_thirds_last]

[accordion class=\'accord2\']
[slide name="Is it possible to customize the layout and design of my website\'s Header area?"]Yes indeed. Karma offers a variety of super easy-to-use styling options for a fully custom Header design. Toggle the top-toolbar, adjust the header height, add widgets, select a custom pattern overlay image and more. You can also use Karma\'s powerful logo options to position your company\'s logo to the left, right or center. [/slide]

[slide name="What are some of the color scheme options that come with this theme?"]Karma was designed by an award-winning graphic design team. It comes packed with 30 gorgeous color schemes making Karma the perfect WordPress theme for every type of business. Powerful administration options also enable you to build your very own custom color scheme. Oh and you can also choose a color scheme on a per-page basis allowing for a different color scheme on each and every page of your website.[/slide]

[slide name="Does Karma display nicely on Retina display?"]Yes indeed. Over 90% of the Karma theme is completely retina-ready right out of the box. The image frame shortcodes are one of the only non-retina items however they still look super-duper gorgeous. Uploading a Retina-ready logo is only a mouse click away. Fire up your retina display and go have a look - you won\'t be disappointed.[/slide]

[slide name="Any other design customizations I should know about?"]Yes. There are an absolute abundant amount of design and customization options available in this theme. The even cooler part is that we\'ve spent an incredible amount of time in the planning and implementation of these options ensuring that every option baked into Karma is only a few mouse clicks away. Be sure to check out the Design section of this demo site for a more in-depth look.[/slide]

[/accordion]
[/two_thirds_last]

[gap size="20px"]

[one_third]

[tt_vector_box icon="fa-gift" size="fa-4x" color="#9F86D2" link_to_page="" target="" description=""]
<h3>Features</h3>
Built for the future

[/tt_vector_box]

[/one_third]

[two_thirds_last]

[accordion class=\'accord3\']

[slide name="Does this theme come pre-translated into any other Languages?"]Yes. Karma comes translated in over 10 international languages. We\'ve invested time and money to ensure that you can translate your website with the utmost ease. Languages include: English, Čeština, Deutsch, Español, Français, Italiano, Chinese, Nederlands, Polski, Português, Русский, Türkçe, Japanese.[/slide]
[slide name="I see that Karma is Accessibility Compliant. What is Accessibility and why it is important?"]Web accessibility means that people with disabilities can use and access your website. More specifically, Web accessibility means that people with disabilities can perceive, understand, navigate, and interact with the Web, and that they can contribute to the Web. During the re-build of Karma we teamed up with an Accessibility Expert to audit the theme and provide guidance about where to improve the theme for greater accessibility.[/slide]

[slide name="Does Karma freely include popular plugins such as LayerSlider and Revolution Slider?"]Yes. We\'ve invested a nice chunk of money to provide you with the highly popular LayerSlider, Slider Revolution and 3D CU3ER Slider Plugins. Karma is fully optimized, seamlessly integrated and ready to rock-and-roll right out of the box. All plugins are kept entirely up to date so that you can keep your money in your pocket and add amazing functionality to your website.[/slide]

[slide name="Do you offer free customer support with the Karma theme?"]You betchya! In many ways you could say that our main product is outstanding theme support. It\'s what we work on the hardest. 90% of our staff is in some way dedicated to this process. Purchase this theme with confidence in knowing that you will be fully backed by a dedicated team of amazingly friendly website professionals.[/slide]

[slide name="Any other features I should know about?"]Yes. There is an absolute boatload of additional features included in this theme. The most important feature is that Karma is actually usable. We\'ve got a combined 10 years working in the trenches at high-cost marketing firms so we absolutely know what it takes to build a successful and usable website. We continue to get repeat customers because Karma is just so darn easy to use. Please be sure to check out the Features section of this demo site for a more in-depth look.[/slide]

[/accordion]

[/two_thirds_last]',
  		'post_type' => 'page',
		
	);

	$page_post_meta19 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',	
					'truethemes_page_checkbox' => 'on',
						

	);

	$preset_menu_item_id['faq-1'] = tt_create_pages($page_data19,$page_post_meta19);
	
	
	
	
	
	
	



//FAQ - 2
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data102 = array(
  		'post_title'    => 'FAQ - 2',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[one_third]

[tt_vector_box icon="fa-globe" size="fa-4x" color="#32BEEB" link_to_page="" target="" description=""]
<h3>Languages</h3>
Does Karma come translated into any other Languages?

[/tt_vector_box]
[/one_third]

[two_thirds_last]

[callout2]Karma comes pre-translated into 12 international languages. We’ve invested time and money to ensure that you can translate your website with the utmost ease. Languages include: English, Čeština, Deutsch, Español, Français, Italiano, Chinese, Nederlands, Polski, Português, Русский, Türkçe, Japanese.[/callout2]
[/two_thirds_last]

[gap size="40px"]

[one_third]

[tt_vector_box icon="fa-heart" size="fa-4x" color="#54BFC6" link_to_page="" target="" description=""]
<h3>Accessibility</h3>
What is website accessibility and why is it important?

[/tt_vector_box]
[/one_third]

[two_thirds_last]

[callout2]Web accessibility means that people with disabilities can use and access your website. More specifically, Web accessibility means that people with disabilities can perceive, understand, navigate, and interact with the Web, and that they can contribute to the Web. During the re-build of Karma we teamed up with an Accessibility Expert to audit the theme and provide guidance about where to improve the theme for greater accessibility.[/callout2]
[/two_thirds_last]

[gap size="40px"]

[one_third]

[tt_vector_box icon="fa-leaf" size="fa-4x" color="#F1852B" link_to_page="" target="" description=""]
<h3>Sliders</h3>
Does Karma freely include popular plugins such as LayerSlider and Revolution Slider?

[/tt_vector_box]
[/one_third]

[two_thirds_last]
[callout2]Yes. We\'ve invested a nice chunk of money to provide you with the highly popular LayerSlider, Slider Revolution and 3D CU3ER Slider Plugins. Karma is fully optimized, seamlessly integrated and ready to rock-and-roll right out of the box. All plugins are kept entirely up to date so that you can keep your money in your pocket and add amazing functionality to your website.[/callout2]
[/two_thirds_last]

[gap size="40px"]

[one_third]

[tt_vector_box icon="fa-thumbs-o-up" size="fa-4x" color="#F282C7" link_to_page="" target="" description=""]
<h3>Support</h3>
Does Karma come with free support?

[/tt_vector_box]
[/one_third]

[two_thirds_last]
[callout2]You betchya! In many ways you could say that our main product is outstanding theme support. It\'s what we work on the hardest. 90% of our staff is in some way dedicated to this process. Purchase this theme with confidence in knowing that you will be fully backed by a dedicated team of amazingly friendly website professionals.[/callout2]
[/two_thirds_last]

[gap size="40px"]

[one_third]

[tt_vector_box icon="fa-gear" size="fa-4x" color="#B19BDB" link_to_page="" target="" description=""]
<h3>Features</h3>
Anything else I should know about?

[/tt_vector_box]
[/one_third]

[two_thirds_last]
[callout2]Yes. There is an absolute boatload of additional features included in this theme. The most important feature is that Karma is actually usable. We\'ve got a combined 10 years working in the trenches at high-cost marketing firms so we absolutely know what it takes to build a successful and usable website. We continue to get repeat customers because Karma is just so darn easy to use. Please be sure to check out the Features section of this demo site for a more in-depth look.[/callout2]
[/two_thirds_last]',
  		'post_type' => 'page',
		
	);

	$page_post_meta102 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',	
					'truethemes_page_checkbox' => 'on',
						

	);

	$preset_menu_item_id['faq-2'] = tt_create_pages($page_data102,$page_post_meta102);
	
	
	
	
	
	
	
	
	//FAQ - 3
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data103 = array(
  		'post_title'    => 'FAQ - 3',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '<h4>General</h4>
[accordion class=\'accord1\']
[slide name="Can I really use a slider on any page layout?"]Yes. Karma now offers the ability to insert a slider on every page template. When creating a page you\'ll simply use Karma\'s custom \'Slider Settings\' section of the Page Editing screen to customize and insert your Slider. We\'ve made sure to stay true to the default Wordpress interface so absolutely nothing new to learn. Gone are the days of being locked down to a "homepage template". Boo-yah! [/slide]

[slide name="Is it true I can have unlimited Gallery Pages?"]Indeed it is. In Karma 4.0 we have made it possible to create unlimited Gallery Pages using Parent and Child Categories. First you will go to Gallery Posts &gt; Categories in the Wordpress backend, then create a Category, by default it will be a Parent. Now any category you create after just select that previous category as a parent. Each Parent Category represents its own gallery. So now all you have to do is choose the parent category in the page editor for the page you wish to display the gallery on. [/slide]

[slide name="Can I use Shortcodes in a Blog Post?"]Yes you can. We have taken the liberty of putting together some recommended shortcodes for the blog. For recommended Columns <a title="Recommended Columns for Blog" href="http://themes.truethemes.net/Karma-4.0/shortcodes-in-the-blog/" target="_blank">Click Here</a>. And for other Shortcode examples <a title="Shortcodes in the Blog" href="http://themes.truethemes.net/Karma-4.0/shortcodes-in-the-blog-pt-2/" target="_blank">Click Here.</a>[/slide]

[slide name="How is it I can build my own homepage?"]We won\'t get into all the technical jargen. We will however say it is as easy as riding a bike. In Karma 4.0 there is no set homepage layout. We have given you the option to use any of the layout templates (Left Sidebar, Right Nav + Sidebar, ect.) as your homepage layout. Also in the Page Editor we have allowed you to turn off certain elements such as the Title Bar to better suit your homepage needs. Combine that with being able to put a slider on any page and VOILA, you get to make your own homepage. Once again, Have Fun! [/slide]

[slide name="Can I use Google Fonts with Karma 4.0?"]You bet you can. Just travel on over to the custom Site Options Panel (Appearance &gt; Site Options &gt; Fonts). When there you will have the ability to choose from 11 preset samples we have provided for the Google Fonts. Or you have the option to enter your own custom font. Cheers![/slide]
[/accordion]
<h4>Design</h4>
[accordion class=\'accord2\']
[slide name="Is it possible to customize the layout and design of my website\'s Header area?"]Yes indeed. Karma offers a variety of super easy-to-use styling options for a fully custom Header design. Toggle the top-toolbar, adjust the header height, add widgets, select a custom pattern overlay image and more. You can also use Karma\'s powerful logo options to position your company\'s logo to the left, right or center. [/slide]

[slide name="What are some of the color scheme options that come with this theme?"]Karma was designed by an award-winning graphic design team. It comes packed with 30 gorgeous color schemes making Karma the perfect WordPress theme for every type of business. Powerful administration options also enable you to build your very own custom color scheme. Oh and you can also choose a color scheme on a per-page basis allowing for a different color scheme on each and every page of your website.[/slide]

[slide name="Does Karma display nicely on Retina display?"]Yes indeed. Over 90% of the Karma theme is completely retina-ready right out of the box. The image frame shortcodes are one of the only non-retina items however they still look super-duper gorgeous. Uploading a Retina-ready logo is only a mouse click away. Fire up your retina display and go have a look - you won\'t be disappointed.[/slide]

[slide name="Any other design customizations I should know about?"]Yes. There are an absolute abundant amount of design and customization options available in this theme. The even cooler part is that we\'ve spent an incredible amount of time in the planning and implementation of these options ensuring that every option baked into Karma is only a few mouse clicks away. Be sure to check out the Design section of this demo site for a more in-depth look.[/slide]

[/accordion]
<h4>Features</h4>
[accordion class=\'accord3\']

[slide name="Does this theme come pre-translated into any other Languages?"]Yes. Karma comes translated in over 10 international languages. We\'ve invested time and money to ensure that you can translate your website with the utmost ease. Languages include: English, Čeština, Deutsch, Español, Français, Italiano, Chinese, Nederlands, Polski, Português, Русский, Türkçe, Japanese.[/slide]
[slide name="I see that Karma is Accessibility Compliant. What is Accessibility and why it is important?"]Web accessibility means that people with disabilities can use and access your website. More specifically, Web accessibility means that people with disabilities can perceive, understand, navigate, and interact with the Web, and that they can contribute to the Web. During the re-build of Karma we teamed up with an Accessibility Expert to audit the theme and provide guidance about where to improve the theme for greater accessibility.[/slide]

[slide name="Does Karma freely include popular plugins such as LayerSlider and Revolution Slider?"]Yes. We\'ve invested a nice chunk of money to provide you with the highly popular LayerSlider, Slider Revolution and 3D CU3ER Slider Plugins. Karma is fully optimized, seamlessly integrated and ready to rock-and-roll right out of the box. All plugins are kept entirely up to date so that you can keep your money in your pocket and add amazing functionality to your website.[/slide]

[slide name="Do you offer free customer support with the Karma theme?"]You betchya! In many ways you could say that our main product is outstanding theme support. It\'s what we work on the hardest. 90% of our staff is in some way dedicated to this process. Purchase this theme with confidence in knowing that you will be fully backed by a dedicated team of amazingly friendly website professionals.[/slide]

[slide name="Any other features I should know about?"]Yes. There is an absolute boatload of additional features included in this theme. The most important feature is that Karma is actually usable. We\'ve got a combined 10 years working in the trenches at high-cost marketing firms so we absolutely know what it takes to build a successful and usable website. We continue to get repeat customers because Karma is just so darn easy to use. Please be sure to check out the Features section of this demo site for a more in-depth look.[/slide]

[/accordion]
<h4>Top Secret</h4>
[accordion class=\'accord4\']

[slide name="Is it true that TrueThemes has a Child Prodigy on staff?"]I\'m sorry, I don\'t understand the question.[/slide]

[/accordion]',
  		'post_type' => 'page',
		
	);

	$page_post_meta103 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_rightsidebar_horizontalnav.php',
					//'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',
					'sbg_selected_sidebar' => array(0 => '0'),
					'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						

	);

	$preset_menu_item_id['faq-3'] = tt_create_pages($page_data103,$page_post_meta103);











//Full width
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data20 = array(
  		'post_title'    => 'Full Width',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="" description="Karma Responsive Wordpress Theme" float="" lightbox="" lightbox_group="" size="banner_full"]

[one_third]
<h4>Built</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third]
<h4>With</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third_last]
<h4>Love</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[heading_horizontal type="h6" margin_top="20px" margin_bottom="40px"]services we offer:[/heading_horizontal]

[one_fourth]
[tt_vector_box icon="fa-thumbs-o-up" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 1</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.

[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-font" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 2</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-user" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 3</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth_last]
[tt_vector_box icon="fa-users" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 4</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth_last]


[gap size="30px"]
[hr]
[gap size="20px"]
[one_half]
<h5>Tabs Shortcode:</h5>
[tabset tab1="Tabs" tab2="are" tab3="completely" tab4="flexible"]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]

[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab][/tabset]

[/one_half]

[one_half_last]
<h5>Blogpost Shortcode:</h5>
[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="90" layout="default"]

[/one_half_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta20 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',	
					'truethemes_page_checkbox' => 'on',
						

	);

	$preset_menu_item_id['full-width'] = tt_create_pages($page_data20,$page_post_meta20);	
	
	
	
	

//Horizontal Nav
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data21 = array(
  		'post_title'    => 'Horizontal Nav',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => 'Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Aenean lacinia bibendum nulla sed consectetur. Donec id elit non mi porta gravida at eget metus. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Donec ullamcorper nulla non metus auctor fringilla. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.

Sed posuere consectetur est at lobortis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum id ligula porta felis euismod semper. Curabitur blandit tempus porttitor. Lorem ipsum dolor sit amet, consectetur adipiscing elit.

[one_half]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half]

[one_half_last]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half_last]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third_last]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth_last]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta21 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_custom_sub_menu' => 'custom-menu',
						

	);

	$preset_menu_item_id['horizontal-nav'] = tt_create_pages($page_data21,$page_post_meta21);	
	
	
	
	
	
//Left Sidebar
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data22 = array(
  		'post_title'    => 'Left Sidebar',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => 'Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Etiam porta sem malesuada magna mollis euismod. Cras mattis consectetur purus sit amet fermentum. Donec sed odio dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.

[one_half]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="" description="" float="" lightbox="" lightbox_group="" size="two_col_small"]

[/one_half]

[one_half_last]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="" description="" float="" lightbox="" lightbox_group="" size="two_col_small"]

[/one_half_last]

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec id elit non mi porta gravida at eget metus. Etiam porta sem malesuada magna mollis euismod. Cras mattis consectetur purus sit amet fermentum. Donec sed odio dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta22 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_leftsidebar_horizontalnav.php',
					'truethemes_page_checkbox'=>'on',
					'sbg_selected_sidebar' => array(0 => '0'),
					'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						

	);

	$preset_menu_item_id['left-sidebar'] = tt_create_pages($page_data22,$page_post_meta22);	
	
	
	
	
	
//Left Nav
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data23 = array(
  		'post_title'    => 'Left Nav',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="banner_regular"]

Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Aenean lacinia bibendum nulla sed consectetur. Nullam id dolor id nibh ultricies vehicula ut id elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed odio dui.

Donec ullamcorper nulla non metus auctor fringilla. Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec sed odio dui. Etiam porta sem malesuada magna mollis euismod.

Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Etiam porta sem malesuada magna mollis euismod. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Aenean lacinia bibendum nulla sed consectetur. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta23 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_leftnav.php',
					'truethemes_page_checkbox'=>'on',
					'truethemes_custom_sub_menu' => 'custom-menu',
						

	);

	$preset_menu_item_id['left-nav'] = tt_create_pages($page_data23,$page_post_meta23);	
	
	
	
	
	
//Left Nav + Sidebar
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data24 = array(
  		'post_title'    => 'Left Nav + Sidebar',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="banner_small"]

Maecenas faucibus mollis interdum. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Nulla vitae elit libero, a pharetra augue. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas faucibus mollis interdum.

Sed posuere consectetur est at lobortis. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Donec ullamcorper nulla non metus auctor fringilla. Cras mattis consectetur purus sit amet fermentum.

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta24 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_leftnav_sidebar.php',
					'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',
					'sbg_selected_sidebar' => array(0 => '0'),
					'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						

	);

	$preset_menu_item_id['leftnav-sidebar'] = tt_create_pages($page_data24,$page_post_meta24);	
		





//Right Sidebar
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data25 = array(
  		'post_title'    => 'Right Sidebar',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="banner_regular"]

Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ullamcorper nulla non metus auctor fringilla. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.

Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ullamcorper nulla non metus auctor fringilla. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta25 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_rightsidebar_horizontalnav.php',
					//'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',
					'sbg_selected_sidebar' => array(0 => '0'),
					'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						
						

	);

	$preset_menu_item_id['right-sidebar'] = tt_create_pages($page_data25,$page_post_meta25);	
	
	
	
	
	
//Right Nav
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data26 = array(
  		'post_title'    => 'Right Nav',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="" lightbox_group="" size="banner_regular"]

Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Aenean lacinia bibendum nulla sed consectetur. Donec sed odio dui. Cras mattis consectetur purus sit amet fermentum. Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Maecenas sed diam eget risus varius blandit sit amet non magna. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Aenean lacinia bibendum nulla sed consectetur. Donec id elit non mi porta gravida at eget metus.

&nbsp;

[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="115" layout="three_col_small" style="modern"]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta26 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_rightnav.php',
					'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',
					//'sbg_selected_sidebar' => array(0 => '0'),
					//'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						
						

	);

	$preset_menu_item_id['right-nav'] = tt_create_pages($page_data26,$page_post_meta26);	






//Right Nav + Sidebar
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data27 = array(
  		'post_title'    => 'Right Nav + Sidebar',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" link_to_page="" target="" description="" float="" lightbox="" lightbox_group="" size="banner_small"]

Maecenas faucibus mollis interdum. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Nulla vitae elit libero, a pharetra augue. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas faucibus mollis interdum.

Sed posuere consectetur est at lobortis. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Donec ullamcorper nulla non metus auctor fringilla. Cras mattis consectetur purus sit amet fermentum.

Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Aenean lacinia bibendum nulla sed consectetur. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta27 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_rightnav_sidebar.php',
					'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',
					'sbg_selected_sidebar' => array(0 => '0'),
					'sbg_selected_sidebar_replacement' => array(0 => 'Blog Sidebar'),
						
						

	);

	$preset_menu_item_id['rightnav-sidebar'] = tt_create_pages($page_data27,$page_post_meta27);
	
	
	
	



//Video Left
	//notice $page_data5 and $page_id5 variable names, to avoid crashing with later pages.	
	$page_data5 = array(
  		'post_title'    => 'Video Left',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_parent' => $preset_menu_parent_item_id['pages'],
		'post_content' => '[video_left][video_frame]
[iframe url="http://www.youtube.com/embed/rV6wRZRDci0" width="572" height="312"]
[/video_frame]

[video_text]
[h2]Video Layout Shortcode[/h2]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec ullamcorper nulla non metus auctor fringilla.

[button url="http://themeforest.net/item/karma-clean-and-modern-wordpress-theme/168737?ref=TrueThemes" target="_self" size="medium" style="saffronblue" icon="" popup="" title=""]Buy this theme[/button]

[/video_text][/video_left]

[heading_horizontal type="h6" margin_top="20px" margin_bottom="40px"]services we offer:[/heading_horizontal]

[one_fourth]
[tt_vector_box icon="fa-thumbs-o-up" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 1</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.

[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-font" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 2</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-user" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 3</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth_last]
[tt_vector_box icon="fa-users" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 4</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth_last]

[gap size="30px"]

[callout1]Use this text block to engage your customers and promote a rewarding call to action. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris a quam id sem pharetra porttitor. Nulla vitae elit libero, a pharetra augue.[/callout1]

[gap size="30px"]
[one_half]
<h5>Tabs Shortcode:</h5>
[tabset tab1="Tabs" tab2="are" tab3="completely" tab4="flexible"]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]

[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab][/tabset]

[/one_half]

[one_half_last]
<h5>Blogpost Shortcode:</h5>
[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="90" layout="default"]

[/one_half_last]',
		
	);

	$page_post_meta5 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox' => 'on',
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	

	);

	$preset_menu_item_id['video-left'] = tt_create_pages($page_data5,$page_post_meta5);	
	
	







//Video Right
	//notice $page_data6 and $page_id6 variable names, to avoid crashing with later pages.	
	$page_data6 = array(
  		'post_title'    => 'Video Right',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
		'post_type' => 'page',
		'post_parent' => $preset_menu_parent_item_id['pages'],
		'post_content' => '[video_right][video_frame]
[iframe url="http://www.youtube.com/embed/rV6wRZRDci0" width="572" height="312"]
[/video_frame]

[video_text]
[h2]Video Layout Shortcode[/h2]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Donec ullamcorper nulla non metus auctor fringilla.

[button url="http://themeforest.net/item/karma-clean-and-modern-wordpress-theme/168737?ref=TrueThemes" target="_self" size="medium" style="saffronblue" icon="" popup="" title=""]Buy this theme[/button]

[/video_text][/video_right]

[heading_horizontal type="h6" margin_top="20px" margin_bottom="40px"]services we offer:[/heading_horizontal]

[one_fourth]
[tt_vector_box icon="fa-thumbs-o-up" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 1</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.

[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-font" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 2</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth]
[tt_vector_box icon="fa-user" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 3</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth]

[one_fourth_last]
[tt_vector_box icon="fa-users" size="fa-4x" color="" link_to_page="" target="" description=""]
<h4>Service 4</h4>
[/tt_vector_box]

Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Cras mattis consectetur purus sit amet fermentum.
[/one_fourth_last]

[gap size="30px"]

[callout1]The contact form below was created in less than 2 minutes using Karma\'s powerful Form Builder. Contact forms can be inserted into any area of your website including pages, posts, footer and sidebar regions. This form below is for demo purposes only and will mail out to our auto-response system.[/callout1]

[gap size="30px"]
[one_half]
<h4>Contact Form Shortcode:</h4>
[raw][contact-form subject="Subject Line to Email Here" to="hello@truethemes.net"]
[contact-field label="Name" type="name" required="true" /]
[contact-field label="Email" type="email" required="true" /]
[contact-field label="Comment" type="textarea" required="true" /]
[/contact-form][/raw]

[/one_half]

[one_half_last]
<h4>Blogpost Shortcode:</h4>
[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="90" layout="default"]

[/one_half_last]',
		
	);

	$page_post_meta6 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox' => 'on',
						
					//Page settings
    				'slider_disable_toolbar'=>'true',	
	

	);

	$preset_menu_item_id['video-right'] = tt_create_pages($page_data6,$page_post_meta6);		
	
	
	
		


	
	



	
	//Page sample
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data28 = array(
  		'post_title'    => 'Sample - Side Nav + Image Frames',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => 'Curabitur blandit tempus porttitor. Maecenas sed diam eget risus varius blandit sit amet non magna. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Cras mattis consectetur purus sit amet fermentum. Cras mattis consectetur purus sit amet fermentum.

[heading_horizontal type="h6" margin_top="20px" margin_bottom="60px"]Modern Image Frames[/heading_horizontal]

[one_half]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_small"]

[/one_half]

[one_half_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_small"]

[/one_half_last]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third_last]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth_last]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_regular"]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_small"]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="square"]

[heading_horizontal type="h6" margin_top="60px" margin_bottom="60px"]Shadow Image Frames[/heading_horizontal]

[one_half]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_small"]

[/one_half]

[one_half_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_small"]

[/one_half_last]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third]

[one_third_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_small"]

[/one_third_last]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth]

[one_fourth_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_small"]

[/one_fourth_last]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_regular"]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_small"]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="square"]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta28 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template_leftnav.php',
					'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',

						

	);

	$preset_menu_item_id['sample-sidenav-image-frames'] = tt_create_pages($page_data28,$page_post_meta28);
	
	
	

//Button Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data29 = array(
  		'post_title'    => 'Buttons',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[one_fourth]
<h6>Royal Blue</h6>
[button size="small" style="royalblue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="royalblue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="royalblue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Political Blue</h6>
[button size="small" style="politicalblue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="politicalblue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="politicalblue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Cool Blue</h6>
[button size="small" style="coolblue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="coolblue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="coolblue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Sky Blue</h6>
[button size="small" style="skyblue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="skyblue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="skyblue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Vista Blue</h6>
[button size="small" style="vistablue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="vistablue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="vistablue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Black</h6>
[button size="small" style="black" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="black" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="black" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Teal Grey</h6>
[button size="small" style="tealgrey" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="tealgrey" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="tealgrey" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Grey</h6>
[button size="small" style="grey" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="grey" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="grey" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Blue Grey</h6>
[button size="small" style="bluegrey" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="bluegrey" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="bluegrey" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Saffron Blue</h6>
[button size="small" style="saffronblue" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="saffronblue" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="saffronblue" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Steel Green</h6>
[button size="small" style="steelgreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="steelgreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="steelgreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Tuf Green</h6>
[button size="small" style="tufgreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="tufgreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="tufgreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Silver</h6>
[button size="small" style="silver" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="silver" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="silver" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Coffee</h6>
[button size="small" style="coffee" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="coffee" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="coffee" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Autumn</h6>
[button size="small" style="autumn" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="autumn" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="autumn" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Teal</h6>
[button size="small" style="teal" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="teal" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="teal" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Alpha Green</h6>
[button size="small" style="alphagreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="alphagreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="alphagreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>French Green</h6>
[button size="small" style="frenchgreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="frenchgreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="frenchgreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Yogi Green</h6>
[button size="small" style="yogigreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="yogigreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="yogigreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Forest Green</h6>
[button size="small" style="forestgreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="forestgreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="forestgreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Lime Green</h6>
[button size="small" style="limegreen" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="limegreen" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="limegreen" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Golden</h6>
[button size="small" style="golden" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="golden" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="golden" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Orange</h6>
[button size="small" style="orange" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="orange" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="orange" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Fire</h6>
[button size="small" style="fire" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="fire" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="fire" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Buoy Red</h6>
[button size="small" style="buoyred" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="buoyred" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="buoyred" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Cherry</h6>
[button size="small" style="cherry" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="cherry" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="cherry" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Purple</h6>
[button size="small" style="purple" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="purple" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="purple" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth_last]
<h6>Pink</h6>
[button size="small" style="pink" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="pink" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="pink" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth_last]

[one_fourth]
<h6>Periwinkle</h6>
[button size="small" style="periwinkle" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="periwinkle" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="periwinkle" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
<h6>Violet</h6>
[button size="small" style="violet" url="#" target="" icon="" popup="" title=""]Small Button[/button]
[button size="medium" style="violet" url="#" target="" icon="" popup="" title=""]Medium Button[/button]
[button size="large" style="violet" url="#" target="" icon="" popup="" title=""]Large Button[/button]
[/one_fourth]

[one_fourth]
[/one_fourth]

[one_fourth_last]
[/one_fourth_last]

[gap size="50px"]
<p style="text-align: center; padding-bottom: 25px;">[button size="large" style="royalblue" url="#" target="" icon="" popup="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" title=""]All Buttons are fully flexible and can easily Open Content in a Lightbox.[/button]</p>
[gap size="30px"]

[heading_horizontal type="h3" margin_top="40px" margin_bottom="40px"]Buttons with Icons[/heading_horizontal]
<p style="text-align: center; padding-bottom: 25px;">Choose from over <a href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank">360 font-awesome icons</a>. Here are just a few samples...</p>
[one_third]

[button size="medium" style="royalblue" url="#" target="" icon="fa-cloud-download" popup="" title=""]Download File[/button]

[/one_third]

[one_third]

[button size="medium" style="skyblue" url="#" target="" icon="fa-skype" popup="" title=""]Call us on Skype[/button]

[/one_third]

[one_third_last]

[button size="medium" style="buoyred" url="#" target="" icon="fa-calendar-o" popup="" title=""]View Calendar[/button]

[/one_third_last]

[one_third]

[button size="medium" style="royalblue" url="#" target="" icon="fa-facebook-square" popup="" title=""]Like Us on Facebook[/button]

[/one_third]

[one_third]

[button size="medium" style="skyblue" url="#" target="" icon="fa-twitter" popup="" title=""]Follow us on Twitter[/button]

[/one_third]

[one_third_last]

[button size="medium" style="buoyred" url="#" target="" icon="fa-file-o" popup="" title=""]Download PDF[/button]

[/one_third_last]

[one_third]

[button size="medium" style="royalblue" url="#" target="" icon="fa-picture-o" popup="" title=""]View Photo Gallery[/button]

[/one_third]

[one_third]

[button size="medium" style="skyblue" url="#" target="" icon="fa-envelope" popup="" title=""]Send us Email[/button]

[/one_third]

[one_third_last]

[button size="medium" style="buoyred" url="#" target="" icon="fa-youtube-play" popup="" title=""]Video Preview[/button]

[/one_third_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta29 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					//'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['buttons'] = tt_create_pages($page_data29,$page_post_meta29);
	
	
	
	
	
//Callout boxes	
//
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data30 = array(
  		'post_title'    => 'Callout Boxes',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="60px"]Callout Boxes[/heading_horizontal]

[one_half]

[callout style="royalblue" font_size="13px"]
<h6>Royal Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="coolblue" font_size="13px"]
<h6>Cool Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="vistablue" font_size="13px"]
<h6>Vista Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="tealgrey" font_size="13px"]
<h6>Teal Grey</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="bluegrey" font_size="13px"]
<h6>Blue Grey</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="steelgreen" font_size="13px"]
<h6>Steel Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="silver" font_size="13px"]
<h6>Silver</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="autumn" font_size="13px"]
<h6>Autumn</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="alphagreen" font_size="13px"]
<h6>Alpha Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="yogigreen" font_size="13px"]
<h6>Yogi Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="limegreen" font_size="13px"]
<h6>Lime Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="orange" font_size="13px"]
<h6>Orange</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="buoyred" font_size="13px"]
<h6>Buoy Red</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="purple" font_size="13px"]
<h6>Purple</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="periwinkle" font_size="13px"]
<h6>Periwinkle</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[/one_half]

[one_half_last]

[callout style="politicalblue" font_size="13px"]
<h6>Political Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="skyblue" font_size="13px"]
<h6>Sky Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="black" font_size="13px"]
<h6>Black</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="grey" font_size="13px"]
<h6>Grey</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="saffronblue" font_size="13px"]
<h6>Saffron Blue</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="tufgreen" font_size="13px"]
<h6>Tuf Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="coffee" font_size="13px"]
<h6>Coffee</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="teal" font_size="13px"]
<h6>Teal</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="frenchgreen" font_size="13px"]
<h6>French Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="forestgreen" font_size="13px"]
<h6>Forest Green</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="golden" font_size="13px"]
<h6>Golden</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="fire" font_size="13px"]
<h6>Fire</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="cherry" font_size="13px"]
<h6>Cherry</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="pink" font_size="13px"]
<h6>Pink</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[callout style="violet" font_size="13px"]
<h6>Violet</h6>
Donec ullamcorper nulla non metus auctor fringilla. Nullam quis risus eget urna mollis ornare vel eu leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>

[/callout]

[/one_half_last]

[callout style="politicalblue" font_size="16px"]

All Callout Boxes have a completely flexible width and can accept any custom font-size.

[/callout]

[heading_horizontal type="h6" margin_top="40px" margin_bottom="60px"]Notification Boxes[/heading_horizontal]

[one_half]
[notify_box style="green"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>[/notify_box]
[notify_box style="red"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>[/notify_box]
[/one_half]

[one_half_last]
[notify_box style="blue"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>[/notify_box]
[notify_box style="yellow"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam lacinia facilisis nibh, ut imperdiet massa sagittis id. In hac habitasse platea dictumst. <a href="#">Sample link</a>[/notify_box]
[/one_half_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta30 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					//'truethemes_custom_sub_menu' => 'custom-menu',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['callout-boxes'] = tt_create_pages($page_data30,$page_post_meta30);
	




//Columns Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data31 = array(
  		'post_title'    => 'Columns',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[one_half]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half]

[one_half_last]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half_last]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third_last]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth_last]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth_last]

[one_fifth]
<h4>1/5</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fifth]

[one_fifth]
<h4>1/5</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fifth]

[one_fifth]
<h4>1/5</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fifth]

[one_fifth]
<h4>1/5</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fifth]

[one_fifth_last]
<h4>1/5</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fifth_last]

[one_sixth]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth]

[one_sixth]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth]

[one_sixth]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth]

[one_sixth]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth]

[one_sixth]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth]

[one_sixth_last]
<h4>1/6</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_sixth_last]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[three_fourth_last]
<h4>3/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/three_fourth_last]

[three_fourth]
<h4>3/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/three_fourth]

[one_fourth_last]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth_last]

[two_thirds]
<h4>2/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/two_thirds]

[one_third_last]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[two_thirds_last]
<h4>2/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/two_thirds_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta31 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['columns'] = tt_create_pages($page_data31,$page_post_meta31);
	





//Image Frames + Lightboxes Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data33 = array(
  		'post_title'    => 'Image Frames',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="60px"]Modern Image Frames[/heading_horizontal]

[one_half]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_large"]

[/one_half]

[one_half_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_large"]

[/one_half_last]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third_last]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth_last]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third]

[one_third]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third]

[one_third_last]
[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third_last]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_full"]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_regular"]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_small"]

[frame style="modern" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="square"]

[heading_horizontal type="h6" margin_top="60px" margin_bottom="60px"]Shadow Image Frames[/heading_horizontal]

[one_half]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_large"]

[/one_half]

[one_half_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="two_col_large"]

[/one_half_last]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third]

[one_third_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="three_col_large"]

[/one_third_last]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth]

[one_fourth_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="four_col_large"]

[/one_fourth_last]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third]

[one_third]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third]

[one_third_last]
[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="portrait_thumb"]

[/one_third_last]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_full"]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_regular"]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="banner_small"]

[frame style="shadow" image_path="http://s3.truethemes.net/theme-xml-content/wp-karma-4/karma-demo.jpg" description="" link_to_page="" target="" float="" lightbox="#" lightbox_group="" size="square"]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta33 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['image-frames'] = tt_create_pages($page_data33,$page_post_meta33);	
	
	
	
//Latest Blog Posts Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data34 = array(
  		'post_title'    => 'Latest Blog Posts',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="50px"]Small Thumbs[/heading_horizontal]

[one_half]

[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="115" layout="default"]

[/one_half]

[one_half_last]

[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="115" layout="default"]

[/one_half_last]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Modern - 2 column[/heading_horizontal]

[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="115" layout="two_col_large" style="modern"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Modern - 3 column[/heading_horizontal]

[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="115" layout="three_col_large" style="modern"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Modern - 4 column[/heading_horizontal]

[blog_posts count="4" post_category="" title="" link_text="Read More" character_count="115" layout="four_col_large" style="modern"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Shadow - 2 column[/heading_horizontal]

[blog_posts count="2" post_category="" title="" link_text="Read More" character_count="115" layout="two_col_large" style="shadow"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Shadow - 3 column[/heading_horizontal]

[blog_posts count="3" post_category="" title="" link_text="Read More" character_count="115" layout="three_col_large" style="shadow"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="50px"]Shadow - 4 column[/heading_horizontal]

[blog_posts count="4" post_category="" title="" link_text="Read More" character_count="115" layout="four_col_large" style="shadow"]

&nbsp;',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta34 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['latest-blog-posts'] = tt_create_pages($page_data34,$page_post_meta34);
	
	
	
//Social Media Icons Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data35 = array(
  		'post_title'    => 'Social Media Icons',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="30px"]Vector Icons[/heading_horizontal]

[social style="vector" show_title="true" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="30px"]Vector Icons - No Title[/heading_horizontal]

[social style="vector" show_title="false" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="30px"]Vector Color Icons[/heading_horizontal]

[social style="vector_color" show_title="true" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="30px"]Vector Color Icons - No Title[/heading_horizontal]

[social style="vector_color" show_title="false" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]

[heading_horizontal type="h6" margin_top="50px" margin_bottom="30px"]Image Icons - No Title[/heading_horizontal]

[social style="image" show_title="false" rss="#" twitter="#" facebook="#" email="#" flickr="#" youtube="#" linkedin="#" pinterest="#" foursquare="#" delicious="#" digg="#" google="#" dribbble="#" skype="#" rss_title="RSS" twitter_title="Twitter" facebook_title="Facebook" email_title="Email" flickr_title="Flickr" youtube_title="YouTube" linkedin_title="Linkedin" pinterest_title="Pinterest" foursquare_title="FourSquare" delicious_title="Delicious" digg_title="Digg" google_title="Google +" dribbble_title="Dribbble" skype_title="Skype"]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta35 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['social-media-icons'] = tt_create_pages($page_data35,$page_post_meta35);	
	
	
	
	
	
	
//Tabs + Accordions Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data36 = array(
  		'post_title'    => 'Tabs + Accordions',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="50px"]Tabs[/heading_horizontal]

[tabset tab1="Tab Sample 1" tab2="Tab Sample 2" tab3="Tab Sample 3 with really long title"]
[tab]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third]

[one_third_last]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[/tab]

[tab]

[two_thirds]
<h4>2/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/two_thirds]

[one_third_last]
<h4>1/3</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_third_last]

[/tab]

[tab]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth_last]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth_last]

[/tab]

[/tabset]

[one_half]
[tabset tab1="Tabs" tab2="are" tab3="completely" tab4="flexible"]
[tab] tab 1 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab] tab 2 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab] tab 3 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]

[tab] tab 4 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab][/tabset]

[/one_half]

[one_half_last]

[tabset tab1="Tabs" tab2="are" tab3="completely" tab4="flexible"]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]
[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab]

[tab]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.[/tab][/tabset]

[/one_half_last]

[heading_horizontal type="h6" margin_top="30px" margin_bottom="60px"]Accordions[/heading_horizontal]

[accordion class="accordion1" active="2"]
[slide name="Accordion Sample 1"]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[one_fourth_last]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth_last]

[/slide]
[slide name="Accordion Sample 2"]

[one_half]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half]

[one_half_last]
<h4>1/2</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_half_last]

[/slide]
[slide name="Accordion Sample 3"]

[one_fourth]
<h4>1/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/one_fourth]

[three_fourth_last]
<h4>3/4</h4>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut quis sem nibh. Proin fringilla, lectus vitae vestibulum facilisis, est justo tempus orci, vel laoreet diam eros placerat elit. Pellentesque facilisis tempus velit sit amet porttitor. Proin nibh magna, porttitor accumsan malesuada non, auctor id tortor.

[/three_fourth_last]

[/slide]
[/accordion]

[two_thirds]
[accordion class="accord2" active="2"]
[slide name="Accordions"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="are"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="completely"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="flexible"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide] [/accordion]

[/two_thirds]

[one_third_last]
[accordion class="accordion3" active="3"]
[slide name="Accordions"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="are"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="completely"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="flexible"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide] [/accordion]
[/one_third_last]

[accordion class="accord4" active="2"]
[slide name="Accordions"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="are"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="completely"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide]
[slide name="flexible"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et dui ligula, sit amet rhoncus erat. Mauris convallis, metus id fermentum consequat, orci felis vestibulum arcu, a molestie nisi risus non elit. Integer dolor turpis, lacinia eu ultricies in, venenatis et odio. Sed malesuada nibh sit amet purus dapibus faucibus.[/slide] [/accordion]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta36 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['tabs-accordions'] = tt_create_pages($page_data36,$page_post_meta36);	






//Testimonial + Tweets Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data37 = array(
  		'post_title'    => 'Testimonials + Tweets',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="50px"]Testimonial Slider[/heading_horizontal]

[testimonial_wrap]
[testimonial]Thanks so much for fixing my issue so quickly, I would just like to say that your company has provided such amazing customer service/ support to date it has really blown me away (it is very rare in business today)[client_name]Themeforest Member[/client_name][/testimonial]
[testimonial]Pretty impressed with the customer service from TrueThemes. I have rarely seen such after purchase customer service. He actually logged into my server , fixed the file and sent me an explanation on how he fixed it. I am glad I made this purchase.If you are looking for a great theme and great after purchase service , you have found the guy right here...[client_name]Themeforest Member[/client_name][/testimonial]
[testimonial]Thanks again for helping me, I just want to say your level of attention to your theme buyers on providing tech support has been amazing. From helping me with 3rd party plugins to fixing CSS code in my site, I have never got this amount of support from buying a theme anywhere else, and I\'ve purchased lot of themes in my day. You provide the best level of support, and I really appreciate you helping me with my website.[client_name]Themeforest Member[/client_name][/testimonial]
[testimonial]I have downloaded 8 themes from themeforest. This has been the easiest to customize out of them all. I\'ve never turned a website around so fast! I\'ll be looking for more themes from fivesquared in the future. Thanks![client_name]Themeforest Member[/client_name][/testimonial]

[/testimonial_wrap]

&nbsp;

&nbsp;

[heading_horizontal type="h6" margin_top="30px" margin_bottom="45px"]Latest Tweets[/heading_horizontal]

[one_half]
<h4>TrueThemes</h4>
[latest_tweets user=\'truethemes\' num=\'5\' retweets=\'false\']
[/one_half]

[one_half_last]
<h4>Envato</h4>
[latest_tweets user="envato" num="5" retweets=\'false\']
[/one_half_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta37 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['testimonial-tweets'] = tt_create_pages($page_data37,$page_post_meta37);
	
	
	
	
	
	
	
	
	
	
	//Typography Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data38 = array(
  		'post_title'    => 'Typography',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="20px"]Heading with Horizontal Line[/heading_horizontal]

Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

[gap size="30px"]

[callout1]Callout Text 1. Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.[/callout1]

[gap size="30px"]

[callout2]Callout Text 2. Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.[/callout2]

&nbsp;
<h1></h1>
<h1>Heading 1</h1>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
<h2>Heading 2</h2>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
<h3>Heading 3</h3>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
<h4>Heading 4</h4>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
<h5>Heading 5</h5>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.
<h6>Heading 6</h6>
Lorem Ipsum Doloe cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Etiam porta sem malesuada magna mollis euismod. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas faucibus mollis interdum. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.

[heading_horizontal type="h2" margin_top="80px" margin_bottom="80px"]List Shortcodes[/heading_horizontal]

[one_fourth]
[arrow_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/arrow_list]

[/one_fourth]

[one_fourth]

[caret_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/caret_list]

[/one_fourth]

[one_fourth]

[check_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/check_list]

[/one_fourth]

[one_fourth_last]

[circle_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/circle_list]

[/one_fourth_last]

[gap size="10px"]

[one_fourth]

[double_angle_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/double_angle_list]

[/one_fourth]

[one_fourth]

[full_arrow_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/full_arrow_list]

[/one_fourth]

[one_fourth]

[plus_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/plus_list]

[/one_fourth]

[one_fourth_last]

[star_list]

[list_item]Item 1...[/list_item]

[list_item]Item 2...[/list_item]

[list_item]Item 3...[/list_item]

[/star_list]

[/one_fourth_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta38 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['typography'] = tt_create_pages($page_data38,$page_post_meta38);
	
	
	
	
	
	
	
	//Vector Icons Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data39 = array(
  		'post_title'    => 'Vector Icons',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[heading_horizontal type="h6" margin_top="20px" margin_bottom="40px"]FontAwesome Icons[/heading_horizontal]
<p style="text-align: center; padding-bottom: 40px;">100% Vector and Retina-ready. Choose from over <strong><a href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank">360 font-awesome icons</a></strong>. Here is 48 of our favorites for you to sample...</p>
[one_sixth]
[tt_vector icon="fa-cloud-download" size="fa-3x" border="false" pull="" color=""]
fa-cloud-download
[/one_sixth]
[one_sixth]

[tt_vector icon="fa-calendar" size="fa-3x" border="false" pull="" color=""]
fa-calendar
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-camera" size="fa-3x" border="false" pull="" color=""]
fa-camera
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-envelope" size="fa-3x" border="false" pull="" color=""]
fa-envelope
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-home" size="fa-3x" border="false" pull="" color=""]
fa-home
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-tags" size="fa-3x" border="false" pull="" color=""]
fa-tags
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-comments" size="fa-3x" border="false" pull="" color=""]
fa-comments
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-rocket" size="fa-3x" border="false" pull="" color=""]
fa-rocket
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-question-circle" size="fa-3x" border="false" pull="" color=""]
fa-question-circle
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-user" size="fa-3x" border="false" pull="" color=""]
fa-user
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-truck" size="fa-3x" border="false" pull="" color=""]
fa-truck
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-sitemap" size="fa-3x" border="false" pull="" color=""]
fa-sitemap
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-rss" size="fa-3x" border="false" pull="" color=""]
fa-rss
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-twitter" size="fa-3x" border="false" pull="" color=""]
fa-twitter
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-facebook" size="fa-3x" border="false" pull="" color=""]
fa-facebook
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-dribbble" size="fa-3x" border="false" pull="" color=""]
fa-dribbble
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-pinterest" size="fa-3x" border="false" pull="" color=""]
fa-pinterest
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-skype" size="fa-3x" border="false" pull="" color=""]
fa-skype
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-arrow-circle-up" size="fa-3x" border="false" pull="" color=""]
fa-arrow-circle-up
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-arrow-circle-down" size="fa-3x" border="false" pull="" color=""]
fa-arrow-circle-down
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-arrow-left" size="fa-3x" border="false" pull="" color=""]
fa-arrow-left
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-arrow-right" size="fa-3x" border="false" pull="" color=""]
fa-arrow-right
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-chevron-left" size="fa-3x" border="false" pull="" color=""]
fa-chevron-left
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-chevron-right" size="fa-3x" border="false" pull="" color=""]
fa-chevron-right
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-thumbs-up" size="fa-3x" border="false" pull="" color=""]
fa-thumbs-up 
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-thumbs-down" size="fa-3x" border="false" pull="" color=""]
fa-thumbs-down
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-thumbs-o-up" size="fa-3x" border="false" pull="" color=""]
fa-thumbs-o-up
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-thumbs-o-down" size="fa-3x" border="false" pull="" color=""]
fa-thumbs-o-down
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-star" size="fa-3x" border="false" pull="" color=""]
fa-star
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-star-half-o" size="fa-3x" border="false" pull="" color=""]
fa-star-half-o
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-tasks" size="fa-3x" border="false" pull="" color=""]
fa-tasks
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-thumb-tack" size="fa-3x" border="false" pull="" color=""]
fa-thumb-tack
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-tachometer" size="fa-3x" border="false" pull="" color=""]
fa-tachometer
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-shield" size="fa-3x" border="false" pull="" color=""]
fa-shield
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-spinner" size="fa-3x" border="false" pull="" color=""]
fa-spinner
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-search" size="fa-3x" border="false" pull="" color=""]
fa-search
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-signal" size="fa-3x" border="false" pull="" color=""]
fa-signal
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-wrench" size="fa-3x" border="false" pull="" color=""]
fa-wrench
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-users" size="fa-3x" border="false" pull="" color=""]
fa-users
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-volume-down" size="fa-3x" border="false" pull="" color=""]
fa-volume-down
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-volume-up" size="fa-3x" border="false" pull="" color=""]
fa-volume-up
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-upload" size="fa-3x" border="false" pull="" color=""]
fa-upload
[/one_sixth_last]

[one_sixth]

[tt_vector icon="fa-usd" size="fa-3x" border="false" pull="" color=""]
fa-usd
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-euro" size="fa-3x" border="false" pull="" color=""]
fa-euro
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-try" size="fa-3x" border="false" pull="" color=""]
fa-try
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-rub" size="fa-3x" border="false" pull="" color=""]
fa-rub
[/one_sixth]

[one_sixth]

[tt_vector icon="fa-krw" size="fa-3x" border="false" pull="" color=""]
fa-krw
[/one_sixth]

[one_sixth_last]

[tt_vector icon="fa-gbp" size="fa-3x" border="false" pull="" color=""]
fa-gbp
[/one_sixth_last]',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta39 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['vector-icons'] = tt_create_pages($page_data39,$page_post_meta39);	
	
	
	
	
	
	
	
	//Vector Icon Boxes Shortcode
	//change variable names (numbers), to avoid crashing with later pages.	
	$page_data40 = array(
  		'post_title'    => 'Vector Icon Boxes',
  		'post_status'   => 'publish',
  		'post_author'   => 1,
  		'post_content' => '[tt_vector_box icon="fa-thumbs-up" size="fa-4x" color="" link_to_page="" target="" description=""]
<h3>Vector Icon Boxes</h3>
Fully Responsive boxes with over 360+ retina-ready icons. Easily adjust icon size, color and page linking ability.

[/tt_vector_box]

&nbsp;
<h3 style="text-align: center;">Endless Possibilities...</h3>
&nbsp;

[one_half]
[tt_vector_box icon="fa-file-text-o" size="fa-4x" color="#B83435" link_to_page="" target="" description=""]
<h3>PDF Download</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula.

[/tt_vector_box]
[/one_half]

[one_half_last]
[tt_vector_box icon="fa-clock-o " size="fa-4x" color="#87C442" link_to_page="" target="" description=""]
<h3>Meeting Times</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_half_last]

&nbsp;

[one_half]
[tt_vector_box icon="fa-calendar" size="fa-4x" color="#7D60A9" link_to_page="" target="" description=""]
<h3>Event Calendar</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula.

[/tt_vector_box]
[/one_half]

[one_half_last]
[tt_vector_box icon="fa-globe" size="fa-4x" color="#196588" link_to_page="" target="" description=""]
<h3>Global Impact</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_half_last]

&nbsp;
<h3 style="text-align: center;">Flexible Width...</h3>
&nbsp;

[one_third]
[tt_vector_box icon="fa-twitter" size="fa-4x" color="#00ACED" link_to_page="" target="" description=""]
<h3>Twitter</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]

[/one_third]

[one_third]
[tt_vector_box icon="fa-facebook" size="fa-4x" color="#3B5998" link_to_page="" target="" description=""]
<h3>Facebook</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_third]

[one_third_last]
[tt_vector_box icon="fa-pinterest" size="fa-4x" color="#CB2027" link_to_page="" target="" description=""]
<h3>Pinterest</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_third_last]

&nbsp;

[one_third]
[tt_vector_box icon="fa-google-plus" size="fa-4x" color="#D14836" link_to_page="" target="" description=""]
<h3>Google+</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]

[/one_third]

[one_third]
[tt_vector_box icon="fa-rss" size="fa-4x" color="#FF8300" link_to_page="" target="" description=""]
<h3>RSS</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_third]

[one_third_last]
[tt_vector_box icon="fa-skype" size="fa-4x" color="#00AFF0" link_to_page="" target="" description=""]
<h3>Skype</h3>
Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.

[/tt_vector_box]
[/one_third_last]

&nbsp;
<h3 style="text-align: center;">....and over 360 more icons to choose from</h3>
&nbsp;',  		
  		'post_type' => 'page',
		
	);

	$page_post_meta40 = array(
					//set page template, which actually is a post meta!
					'_wp_page_template'=>'template-full-width.php',
					'truethemes_page_checkbox'=>'on',


	);

	$preset_menu_item_id['vector-icon-boxes'] = tt_create_pages($page_data40,$page_post_meta40);		
?>