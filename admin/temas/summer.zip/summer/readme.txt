Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/summer/
Buy theme: http://smthemes.com/buy/summer/
Support Forums: http://smthemes.com/support/forum/summer-free-wordpress-theme/